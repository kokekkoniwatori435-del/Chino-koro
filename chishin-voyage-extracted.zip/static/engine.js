/* ============================================================================
   知の航路 — 採点エンジン（ブラウザ内・サーバー不要）
   src/lib/scoring.ts と同じ判定方針を移植したもの。
   - 文字列完全一致では判定しない
   - 要素グループ「A|B」のいずれかを満たせば充足
   - 正解でも根拠が欠けていれば満点にしない
   - 判定不能なら needs_review
   ========================================================================== */
'use strict';

window.CHISHIN_ENGINE = (function () {
  const VERDICT_RANK = { incorrect: 0, needs_review: 1, partial: 2, correct: 3 };

  function widthNormalize(s) {
    return String(s == null ? '' : s)
      .replace(/[\uFF01-\uFF5E]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
      .replace(/\u3000/g, ' ')
      .replace(/[，、]/g, ',')
      .replace(/[。．]/g, '.')
      .replace(/[「」『』“”"']/g, '');
  }

  function stripMath(s) {
    return s
      .replace(/\\left|\\right/g, '')
      .replace(/\\(?:d|t)?frac\s*\{([^{}]*)\}\s*\{([^{}]*)\}/g, '($1)/($2)')
      .replace(/\\leq?q?/g, '<=')
      .replace(/\\geq?q?/g, '>=')
      .replace(/\\neq/g, '!=')
      .replace(/\\times|\\cdot/g, '*')
      .replace(/\\pm/g, '+-')
      .replace(/\\pi/g, 'pi')
      .replace(/\\theta/g, 'theta')
      .replace(/\\[a-zA-Z]+/g, '')
      .replace(/[{}$]/g, '')
      .replace(/[≦≤]/g, '<=')
      .replace(/[≧≥]/g, '>=')
      .replace(/[×✕]/g, '*')
      .replace(/[÷]/g, '/')
      .replace(/\s+/g, '');
  }

  function normalize(text) {
    return stripMath(widthNormalize(text || '')).toLowerCase();
  }

  function numbersIn(text) {
    const t = stripMath(widthNormalize(text));
    const found = t.match(/-?\d+(?:\.\d+)?(?:\/\d+(?:\.\d+)?)?/g) || [];
    return found.filter((n) => n !== '' && n !== '-');
  }

  function tokenMatch(answer, element) {
    const a = normalize(answer);
    const e = normalize(element);
    if (!e) return true;
    if (a.includes(e)) return true;

    // 数式・数値：要素内の数値がすべて解答に現れる
    const nums = numbersIn(e);
    if (nums.length) {
      const aNums = new Set(numbersIn(a).map((n) => n.replace(/\.0+$/, '')));
      const ok = nums.every((n) => aNums.has(n.replace(/\.0+$/, '')));
      if (ok && /^[\d\s.,+\-*/()^=<>!]+$/.test(e)) return true;
    }

    // トークン照合（75%以上）
    const tokens = e.match(/[a-z]{2,}|[0-9]+(?:\.[0-9]+)?|[\u3040-\u30ff\u4e00-\u9fff]{2,}/g) || [];
    if (tokens.length >= 2) {
      const hit = tokens.filter((tk) => a.includes(tk)).length;
      if (hit / tokens.length >= 0.75) return true;
    }
    if (tokens.length === 1 && tokens[0].length >= 4) {
      return a.includes(tokens[0].slice(0, Math.ceil(tokens[0].length * 0.7)));
    }
    return false;
  }

  function matchesGroup(answer, group) {
    const opts = String(group).split('|').map((x) => x.trim()).filter(Boolean);
    if (!opts.length) return true;
    return opts.some((o) => tokenMatch(answer, o));
  }

  const isObjective = (f) => f === '選択式' || f === '穴埋め式' || f === '数値・式入力';

  function grade(q, answerText, rawAnswer) {
    const maxScore = q.rubric.reduce((a, r) => a + r.points, 0) || 10;
    // 客観形式（選択・穴埋め・数値）は結論欄だけで判定する。
    // 思考欄の文章を混ぜると、正解の記号が埋もれて誤判定になるため。
    const objectiveText = (rawAnswer == null) ? answerText : rawAnswer;
    const normAnswer = normalize(objectiveText);

    let objectiveHit = null;
    if (isObjective(q.answerFormat)) {
      const expected = normalize(q.expectedAnswer);
      objectiveHit = normAnswer === expected || (q.acceptableAnswers || []).some((a) => normalize(a) === normAnswer);
      if (q.choices) {
        const chosen = q.choices.find((c) => normalize(c.label) === normAnswer || normalize(c.text) === normAnswer);
        if (chosen) objectiveHit = Boolean(chosen.correct);
      }
      if (q.numericAnswer) {
        const nums = numbersIn(normAnswer);
        if (nums.length) {
          const v = Number(nums[0]);
          if (!Number.isNaN(v)) objectiveHit = Math.abs(v - q.numericAnswer.value) <= q.numericAnswer.tolerance;
        }
      }
    }

    const rubric = q.rubric.map((item) => {
      const matched = [];
      const missing = [];
      for (const g of item.requiredElements) {
        if (matchesGroup(answerText, g)) matched.push(g);
        else missing.push(g);
      }
      let points = 0;
      if (!item.requiredElements.length) points = 0;
      else if (!missing.length) points = item.points;
      else {
        const ratio = matched.length / item.requiredElements.length;
        points = ratio >= 0.5 ? Math.round(item.points * ratio * 10) / 10 : 0;
      }
      return { criterion: item.criterion, points, maxPoints: item.points, matched, missing, note: item.note };
    });

    if (objectiveHit === true) {
      rubric.forEach((r) => {
        if (r.maxPoints > 0 && r.points < r.maxPoints) { r.points = r.maxPoints; r.note = '客観形式の正答として充足'; }
      });
    }

    if (objectiveHit === null) {
      const expNums = numbersIn(q.expectedAnswer);
      const ansNums = new Set(numbersIn(normAnswer));
      const numsOk = expNums.length > 0 && expNums.every((n) => ansNums.has(n));
      if (numsOk) {
        rubric.forEach((r) => {
          if (/(正答|結論|結果|値)\s*$/.test(r.criterion) && r.points < r.maxPoints) {
            r.points = r.maxPoints;
            r.note = '結論の数値が模範解答と一致';
          }
        });
      }
    }

    const score = Math.round(rubric.reduce((a, r) => a + r.points, 0) * 10) / 10;
    const percent = Math.round((score / maxScore) * 100);

    let verdict;
    if (objectiveHit === true) verdict = 'correct';
    else if (objectiveHit === false) verdict = percent >= 40 ? 'partial' : 'incorrect';
    else if (percent >= 80) verdict = 'correct';
    else if (percent >= 40) verdict = 'partial';
    else verdict = 'incorrect';

    const strengths = rubric.filter((r) => r.maxPoints > 0 && r.points >= r.maxPoints)
      .map((r) => `「${r.criterion}」は十分に書けています。`);
    const gaps = rubric.filter((r) => r.points < r.maxPoints)
      .map((r) => `「${r.criterion}」（${r.points}/${r.maxPoints}点）— ${r.missing.length ? '不足: ' + r.missing.join(' / ') : '内容の精度を高めましょう。'}`);

    const errorTypes = [];
    if (objectiveHit === false) errorTypes.push('answer_mismatch');
    if (rubric.some((r) => /根拠|論理|説明|理由/.test(r.criterion) && r.points < r.maxPoints)) errorTypes.push('insufficient_grounds');
    if (rubric.some((r) => /計算|式|単位|換算/.test(r.criterion) && r.points < r.maxPoints)) errorTypes.push('calculation');
    if (normAnswer.length < 6) errorTypes.push('insufficient_description');

    const logicGaps = [];
    if (verdict !== 'correct' && q.reasoningSteps.length) {
      logicGaps.push(`解答の骨格は「${q.reasoningSteps.map((s) => s.purpose).join(' → ')}」です。どこが抜けたか確認してください。`);
    }

    const nextActions = [];
    if (q.hints && q.hints.length) nextActions.push('ヒントを段階的に開いて、抜けた要素を自力で補ってみましょう。');
    if (q.relatedPatterns && q.relatedPatterns.length) nextActions.push('関連パターンの類題で同じ考え方を使い直しましょう。');

    const needsAi = q.answerFormat === '証明・論証式' || q.answerFormat === '複数解法比較' || q.answerFormat === '計算過程含む記述式';

    return {
      score, maxScore, percent, rubric, verdict, strengths, gaps, logicGaps, errorTypes,
      improvedAnswer: q.expectedAnswer,
      nextActions,
      gradedBy: 'rubric',
      caution: needsAi ? '論証・別解・式変形の妥当性は機械判定では確定できません。必要に応じて「AI添削」を実行してください。' : undefined,
    };
  }

  function merge(base, ai) {
    const merged = Object.assign({}, base, {
      gradedBy: 'rubric+ai',
      ai,
      errorTypes: Array.from(new Set([...(base.errorTypes || []), ...(ai.errorTypes || [])])),
      improvedAnswer: ai.improvedAnswer || base.improvedAnswer,
    });
    if (ai.comment) merged.logicGaps = [...merged.logicGaps, `AI添削: ${ai.comment}`];
    const aiRatio = ai.maxScore ? ai.score / ai.maxScore : 0;
    if (ai.confidence === 'low' && Math.abs(aiRatio - base.score / Math.max(1, base.maxScore)) > 0.35) {
      merged.verdict = 'needs_review';
    }
    return merged;
  }

  return { normalize, numbersIn, matchesGroup, grade, merge, VERDICT_RANK };
})();
