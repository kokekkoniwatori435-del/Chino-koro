/* ============================================================================
   知の航路 — ローカルAPI層（サーバー不要）
   Cloudflare Pages「Upload your static files」で動かすため、
   /api/* 相当の処理をすべてブラウザ内で実行する。
   AI（Gemini）はユーザーが設定画面で入力したキーでブラウザから直接呼び出す。
   キーは localStorage にのみ保存され、いつでも削除できる。
   ========================================================================== */
'use strict';

window.CHISHIN_API = (function () {
  const DIFFS = ['基礎', '応用', '発展', '複合・最難関'];
  const GEMINI_MODELS = ['gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.5-flash', 'gemini-2.5-flash'];
  const GEN_KEY = 'chishin.generated.v1';

  const data = () => window.CHISHIN_DATA || { subjects: [], patterns: [], questions: [] };
  const engine = () => window.CHISHIN_ENGINE;

  function geminiKey() {
    try { return localStorage.getItem('chishin.geminiKey.v1') || ''; } catch { return ''; }
  }

  /** AI はサーバー（Cloudflare secret）優先、なければブラウザキー */
  function aiReady() {
    if (window.CHISHIN_AI) return window.CHISHIN_AI.available();
    return Boolean(geminiKey());
  }

  async function aiRaw(system, user, opts) {
    if (window.CHISHIN_AI) return window.CHISHIN_AI.raw(system, user, opts);
    throw new Error('AIクライアントが読み込まれていません');
  }

  function loadGenerated() {
    try { return JSON.parse(localStorage.getItem(GEN_KEY) || '[]'); } catch { return []; }
  }
  function saveGenerated(list) {
    try { localStorage.setItem(GEN_KEY, JSON.stringify(list.slice(0, 120))); } catch { /* quota */ }
  }

  // 問題はコース単位で遅延読み込みする（初回ロードを軽くするため）
  const QSTORE = {};            // courseId -> question[]
  const loading = {};           // courseId -> Promise

  function authoredQuestions() {
    const out = [];
    Object.keys(QSTORE).forEach((k) => out.push(...QSTORE[k]));
    return out;
  }
  function loadedCount() {
    return authoredQuestions().length;
  }
  function allQuestions() {
    return [...authoredQuestions(), ...loadGenerated()];
  }

  function courseIdOfPattern(pid) {
    const p = findPattern(pid);
    return p ? p.courseId : null;
  }

  /** 1コース分の問題を読み込む（同じコースは再取得しない） */
  function ensureCourse(courseId) {
    if (!courseId) return Promise.resolve([]);
    if (QSTORE[courseId]) return Promise.resolve(QSTORE[courseId]);
    if (loading[courseId]) return loading[courseId];
    loading[courseId] = new Promise((resolve, reject) => {
      const sc = document.createElement('script');
      sc.src = `/data/questions/${courseId}.js`;
      sc.async = true;
      sc.onload = () => {
        const payload = (window.CHISHIN_Q && window.CHISHIN_Q[courseId]) || [];
        QSTORE[courseId] = payload;
        resolve(payload);
      };
      sc.onerror = () => {
        delete loading[courseId];
        reject(new Error(`問題データを読み込めませんでした（${courseId}）`));
      };
      document.head.appendChild(sc);
    });
    return loading[courseId];
  }

  /** 全コースを読み込む（検索・横断機能用） */
  async function ensureAll() {
    const ids = [...new Set((data().patterns || []).map((p) => p.courseId))];
    await Promise.all(ids.map((id) => ensureCourse(id).catch(() => [])));
    return authoredQuestions();
  }
  function questionById(id) {
    return allQuestions().find((q) => q.id === id);
  }
  function questionsByPattern(pid) {
    return allQuestions().filter((q) => q.patternId === pid);
  }

  function manifestRow(pid) {
    const m = (window.CHISHIN_MANIFEST && window.CHISHIN_MANIFEST[pid]) || null;
    return m;
  }

  function coverageFor(pid) {
    const loaded = QSTORE[courseIdOfPattern(pid)] ? (QSTORE[courseIdOfPattern(pid)] || []).filter((q) => q.patternId === pid) : null;
    const m = manifestRow(pid) || { total: 0, byDifficulty: {}, verified: 0 };
    const byDifficulty = m.byDifficulty || {};
    const qs = loaded || [];
    return {
      registered: loaded ? qs.length : m.total,
      verified: loaded ? qs.filter((q) => q.validation === 'verified' || q.validation === 'auto_checked').length : m.verified,
      aiDrafts: loadGenerated().filter((q) => q.patternId === pid).length,
      byDifficulty: loaded
        ? { '基礎': qs.filter((q) => q.difficulty === '基礎').length,
            '応用': qs.filter((q) => q.difficulty === '応用').length,
            '発展': qs.filter((q) => q.difficulty === '発展').length,
            '複合・最難関': qs.filter((q) => q.difficulty === '複合・最難関').length }
        : byDifficulty,
      ids: qs.map((q) => q.id),
    };
  }

  function coverageRows() {
    return (data().patterns || []).map((p) => {
      const c = coverageFor(p.patternId);
      return Object.assign({}, p, {
        registered: c.registered,
        verified: c.verified,
        aiDrafts: c.aiDrafts,
        byDifficulty: c.byDifficulty,
        remaining: Math.max(0, p.target - c.registered),
        status: c.registered === 0 ? 'unregistered' : c.registered >= p.target ? 'complete' : 'in_progress',
      });
    });
  }

  function summary() {
    const rows = coverageRows();
    const bySubject = {};
    rows.forEach((r) => {
      bySubject[r.subjectName] = bySubject[r.subjectName] || { patterns: 0, target: 0, registered: 0, verified: 0 };
      bySubject[r.subjectName].patterns += 1;
      bySubject[r.subjectName].target += r.target;
      bySubject[r.subjectName].registered += r.registered;
      bySubject[r.subjectName].verified += r.verified;
    });
    const qs = authoredQuestions();
    const allRows = rows;
    const registeredTotal = allRows.reduce((a, r) => a + r.registered, 0);
    const verifiedTotal = allRows.reduce((a, r) => a + r.verified, 0);
    const byDifficulty = {};
    DIFFS.forEach((d) => { byDifficulty[d] = qs.filter((q) => q.difficulty === d).length; });
    const byExamType = {};
    qs.forEach((q) => { byExamType[q.examType] = (byExamType[q.examType] || 0) + 1; });

    const units = (data().subjects || []).reduce((a, s) => a + s.courses.reduce((b, c) => b + c.units.length, 0), 0);
    return {
      subjects: (data().subjects || []).length,
      courses: (data().subjects || []).reduce((a, s) => a + s.courses.length, 0),
      units,
      patterns: rows.length,
      targetQuestions: rows.reduce((a, r) => a + r.target, 0),
      registeredQuestions: registeredTotal,
      verifiedQuestions: verifiedTotal,
      aiDraftQuestions: loadGenerated().length,
      patternsWithAnyQuestion: rows.filter((r) => r.registered > 0).length,
      completePatterns: rows.filter((r) => r.status === 'complete').length,
      bySubject,
      byDifficulty,
      byExamType,
      generatedAt: data().generatedAt || new Date().toISOString(),
    };
  }

  function findPattern(pid) {
    return (data().patterns || []).find((p) => p.patternId === pid);
  }
  function findUnit(unitId) {
    for (const s of data().subjects || []) {
      for (const c of s.courses) {
        for (const u of c.units) if (u.id === unitId) return { subject: s, course: c, unit: u };
      }
    }
    return null;
  }

  // ---------------------------------------------------------------- Gemini
  async function geminiJson(system, user, opts) {
    if (!aiReady()) {
      const e = new Error('AIキーが未設定です。Cloudflare のシークレット GEMINI_API_KEY を設定するか、設定画面でキーを入力してください。');
      e.status = 503;
      throw e;
    }
    const { text, model } = await aiRaw(system, user, opts || {});
    return { text, model };
  }

  /**
   * 不正なエスケープ（LaTeX の \, \; \ など）を JSON 用に修復する。
   * モデルが数式を $0\,{}^\circ$ のように書くと JSON.parse が落ちるため。
   */
  function repairJsonEscapes(text) {
    return String(text).replace(/\\(?!["\\/bfnrtu])/g, '\\\\');
  }

  function parseJsonLoose(text) {
    const cleaned = String(text).trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    try { return JSON.parse(cleaned); } catch (e) { /* repair below */ }
    const s = cleaned.indexOf('{');
    const t = cleaned.lastIndexOf('}');
    const body = s >= 0 && t > s ? cleaned.slice(s, t + 1) : cleaned;
    try {
      return JSON.parse(repairJsonEscapes(body));
    } catch (e2) {
      throw new Error('AI応答をJSONとして解釈できませんでした。もう一度お試しください。');
    }
  }

  // ---------------------------------------------------------------- handlers
  const handlers = {
    '/api/health': () => ({
      ok: true,
      ai: aiReady(),
      model: (window.CHISHIN_AI && window.CHISHIN_AI.state.model) || GEMINI_MODELS[0],
      questions: authoredQuestions().length,
      mode: (window.CHISHIN_AI && window.CHISHIN_AI.mode()) || (geminiKey() ? 'browser' : 'none'),
    }),

    '/api/curriculum': () => ({
      subjects: data().subjects || [],
      stats: {
        patterns: (data().patterns || []).length,
        units: (data().subjects || []).reduce((a, s) => a + s.courses.reduce((b, c) => b + c.units.length, 0), 0),
      },
    }),

    '/api/coverage': () => ({ rows: coverageRows(), summary: summary() }),
    '/api/report': () => summary(),

    '/api/patterns': (query) => {
      let rows = coverageRows();
      if (query.subject) rows = rows.filter((r) => r.subjectId === query.subject);
      if (query.course) rows = rows.filter((r) => r.courseId === query.course);
      if (query.q) {
        const n = String(query.q).toLowerCase();
        rows = rows.filter((r) => r.patternName.toLowerCase().includes(n) || r.unitName.toLowerCase().includes(n)
          || String(r.description).toLowerCase().includes(n) || (r.skills || []).some((s) => s.toLowerCase().includes(n)));
      }
      return { rows };
    },

    '/api/questions': (query) => {
      let rows = authoredQuestions();
      if (query.pattern) rows = rows.filter((q) => q.patternId === query.pattern);
      return { questions: rows.map((q) => ({
        id: q.id, patternId: q.patternId, subject: q.subject, course: q.course, unit: q.unit,
        difficulty: q.difficulty, examType: q.examType, answerFormat: q.answerFormat,
        answerLanguage: q.answerLanguage, prompt: q.prompt, validation: q.validation,
      })) };
    },
  };

  async function matchPatternDetail(path) {
    const m = path.match(/^\/api\/patterns\/(.+)$/);
    if (!m) return null;
    const pid = decodeURIComponent(m[1]);
    const p = findPattern(pid);
    if (!p) return undefined;
    await ensureCourse(p.courseId).catch(() => []);
    const u = findUnit(p.unitId);
    const qs = questionsByPattern(pid);
    return {
      pattern: p,
      unit: u ? u.unit : null,
      course: u ? u.course : null,
      questions: qs.map((q) => ({
        id: q.id, difficulty: q.difficulty, examType: q.examType, answerFormat: q.answerFormat,
        prompt: q.prompt, validation: q.validation,
      })),
      coverage: coverageFor(pid),
    };
  }

  async function matchQuestionDetail(path) {
    const m = path.match(/^\/api\/questions\/(.+)$/);
    if (!m) return null;
    const qid = decodeURIComponent(m[1]);
    let q = questionById(qid);
    if (!q) {
      // ID からコースを特定できないため、全コースを順に試す
      const ids = [...new Set((data().patterns || []).map((p) => p.courseId))];
      for (const cid of ids) {
        await ensureCourse(cid).catch(() => []);
        q = questionById(qid);
        if (q) break;
      }
    }
    return q ? { question: q } : undefined;
  }

  async function postGrade(body) {
    let q = questionById(body.questionId);
    if (!q) {
      const ids = [...new Set((data().patterns || []).map((p) => p.courseId))];
      for (const cid of ids) {
        await ensureCourse(cid).catch(() => []);
        q = questionById(body.questionId);
        if (q) break;
      }
    }
    if (!q) { const e = new Error('question not found'); e.status = 404; throw e; }
    const composed = [body.answer || '', ...Object.values(body.reasoning || {})].filter(Boolean).join('\n');
    if (!composed.trim()) { const e = new Error('解答を入力してください'); e.status = 400; throw e; }

    let result = engine().grade(q, composed, body.answer || '');
    if (body.useAi) {
      try {
        const ai = await aiGrade(q, composed, body.language || 'ja');
        result = engine().merge(result, ai);
      } catch (e) {
        result.aiError = e.message;
      }
    }
    return result;
  }

  async function aiGrade(q, attempt, language) {
    const system = [
      'あなたは高校・大学入試の採点者です。模範解答との文字列一致では判定せず、問題ごとの評価基準に沿って意味・論理・根拠を評価します。',
      '- 正解でも根拠が誤っていれば満点にしない',
      '- 計算ミスでも方針・途中式が正しければ部分点を与える',
      '- 数学的・文法的・論理的に正しい別解は認める',
      '- 問題文にない情報を根拠として要求しない',
      '- 判定に確信が持てない場合は confidence を low にし、断定しない',
      '必ず JSON のみを出力してください。',
    ].join('\n');
    const rubricText = q.rubric.map((r) => `- ${r.criterion}（${r.points}点）必須要素: ${(r.requiredElements || []).join(' / ') || '構成・正確性を総合評価'}`).join('\n');
    const user = `【問題】${q.prompt}
${q.passage ? `【本文】${q.passage}\n` : ''}${q.literalTranslation ? `【直訳】${q.literalTranslation}\n` : ''}【模範解答】${q.expectedAnswer}
【許容される別解】${(q.acceptableAnswers || []).join(' / ') || 'なし'}
【評価基準】
${rubricText}
【よくある誤答】${(q.commonErrors || []).map((e) => `${e.error}（理由: ${e.reason}）`).join(' / ') || 'なし'}

【学習者の解答（結論＋根拠）】
${attempt || '（無回答）'}

次のJSON形式で、${language === 'ja' ? '日本語' : '英語'}で出力してください。
{"score": 数値, "maxScore": ${q.rubric.reduce((a, r) => a + r.points, 0)}, "criterionScores": [{"criterion":"", "points":0, "reason":""}], "correctParts": ["正しい部分"], "missingGrounds": ["不足している根拠"], "logicGaps": ["論理の飛躍"], "errorTypes": ["calculation|insufficient_grounds|answer_mismatch|grammar|terminology|misreading"], "improvedAnswer": "改善した解答例", "comment": "総評", "confidence": "high|medium|low"}`;

    const { text, model } = await geminiJson(system, user, { temperature: 0.2, maxOutputTokens: 3000, thinkingBudget: 0 });
    const p = parseJsonLoose(text);
    return {
      model,
      score: Number(p.score) || 0,
      maxScore: Number(p.maxScore) || q.rubric.reduce((a, r) => a + r.points, 0),
      comment: [p.comment, ...((p.missingGrounds || []).map((m) => `不足: ${m}`))].filter(Boolean).join(' / '),
      errorTypes: p.errorTypes || [],
      improvedAnswer: p.improvedAnswer,
      confidence: p.confidence || 'medium',
      detail: p,
    };
  }

  async function postHint(body) {
    let q = questionById(body.questionId);
    if (!q) {
      const ids = [...new Set((data().patterns || []).map((p) => p.courseId))];
      for (const cid of ids) {
        await ensureCourse(cid).catch(() => []);
        q = questionById(body.questionId);
        if (q) break;
      }
    }
    if (!q) { const e = new Error('question not found'); e.status = 404; throw e; }
    const lv = Math.min(Math.max(1, body.level || 1), 3);
    if (q.hints && q.hints[lv - 1]) return { hint: q.hints[lv - 1], level: lv, source: 'authored' };
    if (!geminiKey()) return { hint: '用意されたヒントはここまでです。条件を書き出して、使える知識を整理してみましょう。', level: lv, source: 'fallback' };
    const { text } = await geminiJson(
      'あなたは高校教師です。答えを明かさず、条件整理や考え方の方向だけを段階的に示します。JSONのみ出力。',
      `【問題】${q.prompt}\n【学習者のレベル】ヒント${lv}\nJSON: {"hint":"200字以内のヒント"}`,
      { temperature: 0.5, maxOutputTokens: 1024, thinkingBudget: 0 }
    );
    const p = parseJsonLoose(text);
    return { hint: p.hint, level: lv, source: 'ai' };
  }

  async function postGenerate(body) {
    const p = findPattern(body.patternId);
    if (!p) { const e = new Error('pattern not found'); e.status = 404; throw e; }
    const u = findUnit(p.unitId);
    if (!geminiKey()) {
      const e = new Error('AI生成にはGemini APIキーが必要です。「設定」で入力してください。');
      e.status = 503;
      throw e;
    }
    const system = [
      'あなたは日本の高校・大学入試の作問者です。指定された単元・問題パターンに対して、質の高いオリジナル問題を1問作成します。',
      '禁止: 数値だけを変えた複製、根拠のない事実・語義・訳文の捏造、検証できない出典の提示。',
      '数式は LaTeX（$...$）で記述してください。JSONのみ出力。',
    ].join('\n');
    const user = `【教科】${p.subjectName}
【科目】${p.courseName}
【単元】${p.unitName}（学習目標: ${u ? u.unit.goal : ''}）
【問題パターン】${p.patternName} — ${p.description}
【必要スキル】${(p.skills || []).join(', ')}
【難易度】${body.difficulty || '応用'}（基礎=基本知識の適用 / 応用=複数手順・条件変更 / 発展=初見設定・融合・論証 / 複合・最難関=解法の発見）
【出題形式】${body.examType || '共通テスト型'}

次のJSONのみを出力:
{"prompt":"問題文","passage":"本文や資料（不要なら空文字）","expectedAnswer":"模範解答","acceptableAnswers":["別解"],"reasoningSteps":[{"step":"1","purpose":"","explanation":""}],"evidence":[{"source":"","interpretation":""}],"solution":[{"title":"","body":""}],"rubric":[{"criterion":"","points":2,"requiredElements":[""]}],"commonErrors":[{"error":"","reason":""}],"hints":["","",""],"answerFormat":"記述式","prerequisites":[""]}
配点の合計が10〜15点になるようにし、根拠・論理の評価項目を必ず含めてください。`;

    const { text, model } = await geminiJson(system, user, { temperature: 0.9, maxOutputTokens: 8000, thinkingBudget: 0 });
    const g = parseJsonLoose(text);
    const q = {
      id: `AI-${p.patternId}-${Date.now().toString(36)}`,
      patternId: p.patternId,
      subject: p.subjectName,
      course: p.courseName,
      unit: p.unitName,
      difficulty: body.difficulty || '応用',
      examType: body.examType || '共通テスト型',
      answerFormat: g.answerFormat || '記述式',
      answerLanguage: 'ja',
      prompt: g.prompt,
      passage: g.passage || undefined,
      expectedAnswer: g.expectedAnswer,
      acceptableAnswers: g.acceptableAnswers || [],
      prerequisites: g.prerequisites || [],
      reasoningSteps: g.reasoningSteps || [],
      evidence: g.evidence || [],
      solution: g.solution || [],
      rubric: g.rubric || [],
      commonErrors: g.commonErrors || [],
      alternatives: g.acceptableAnswers || [],
      hints: g.hints || [],
      relatedPatterns: [p.patternId],
      source: `AI生成（${model}）— 未検証`,
      validation: 'ai_generated_unverified',
    };
    const list = loadGenerated();
    list.unshift(q);
    saveGenerated(list);
    return { question: q, validation: 'ai_generated_unverified', model, notice: 'AI生成問題は未検証です。' };
  }

  // ---------------------------------------------------------------- dispatch
  async function request(path, opts) {
    const raw = String(path);
    const qIndex = raw.indexOf('?');
    const pathname = qIndex >= 0 ? raw.slice(0, qIndex) : raw;
    const query = {};
    if (qIndex >= 0) new URLSearchParams(raw.slice(qIndex + 1)).forEach((v, k) => { query[k] = v; });
    const method = ((opts && opts.method) || 'GET').toUpperCase();

    // 少しだけ待たせてローディング表示を成立させる（体感のみ・処理は同期）
    await new Promise((r) => setTimeout(r, 0));

    if (method === 'POST') {
      let body = {};
      try { body = opts && opts.body ? JSON.parse(opts.body) : {}; } catch { body = {}; }
      if (pathname === '/api/grade') return postGrade(body);
      if (pathname === '/api/hint') return postHint(body);
      if (pathname === '/api/generate') return postGenerate(body);
      const e = new Error('not found'); e.status = 404; throw e;
    }

    if (handlers[pathname]) return handlers[pathname](query);
    const pd = await matchPatternDetail(pathname);
    if (pd !== null) {
      if (pd === undefined) { const e = new Error('pattern not found'); e.status = 404; throw e; }
      return pd;
    }
    const qd = await matchQuestionDetail(pathname);
    if (qd !== null) {
      if (qd === undefined) { const e = new Error('question not found'); e.status = 404; throw e; }
      return qd;
    }
    const e = new Error('not found: ' + pathname);
    e.status = 404;
    throw e;
  }

  return { request, summary, coverageRows, findPattern, findUnit, loadGenerated, saveGenerated, geminiKey, aiReady, ensureCourse, ensureAll, loadedCount };
})();
