/* ============================================================================
   知の航路 — views: curriculum / practice / history / coverage / settings
   ========================================================================== */
'use strict';

// ------------------------------------------------------------------ CURRICULUM
function viewCurriculum(el) {
  setCrumbs(['全単元の体系']);
  const activeSubject = S.params.subject || 'jp';
  const subject = S.curriculum.subjects.find((s) => SUBJECT_KEY[s.name] === activeSubject) || S.curriculum.subjects[0];

  const tabs = S.curriculum.subjects.map((s) => {
    const k = SUBJECT_KEY[s.name];
    return `<button class="tab ${k === activeSubject ? 'active' : ''}" data-subject="${k}">${esc(s.name)}</button>`;
  }).join('');

  const courses = subject.courses.map((c) => courseBlock(c)).join('');

  el.innerHTML = `
    <h1 class="serif" style="font-size:1.65rem;margin:0 0 6px">全単元の体系</h1>
    <p style="color:var(--ink-2);font-size:.88rem;max-width:780px">
      教科 → 科目 → 大分野 → 単元 → 小単元 → 問題パターン の順に整理しています。
      各単元には学習目標・前提知識・重要語句・考え方・他単元との関連・問題パターンを紐づけています。
    </p>
    <div class="tabs" style="margin-top:18px">${tabs}</div>
    ${courses || '<div class="empty">この教科にはまだ単元が登録されていません。</div>'}
  `;

  $$('.tab', el).forEach((t) => t.addEventListener('click', () => {
    location.hash = `#/curriculum?subject=${t.dataset.subject}`;
  }));
  $$('.unit-head', el).forEach((h) => h.addEventListener('click', () => h.closest('.unit').classList.toggle('open')));
  $$('[data-practice]', el).forEach((b) => b.addEventListener('click', () => {
    location.hash = `#/practice?pattern=${encodeURIComponent(b.dataset.practice)}`;
  }));
  if (!el.querySelector('.unit.open') && el.querySelector('.unit')) el.querySelector('.unit').classList.add('open');
  renderMath(el);
}

function courseBlock(c) {
  const unitBlocks = c.units.map((u) => unitBlock(c, u)).join('');
  return `
    <section class="course-block">
      <div class="course-head">
        <div>
          <h3>${esc(c.name)}</h3>
          <div class="course-desc">${esc(c.note || '')}${c.status === 'catalog_only' ? ' <span class="chip chip-warn" style="margin-left:6px">問題は未登録（AI生成で追加可）</span>' : ''}</div>
        </div>
        <span class="chip mono">${c.units.length} UNITS</span>
      </div>
      ${unitBlocks}
    </section>`;
}

function unitBlock(c, u) {
  const rows = u.patterns.map((p) => {
    const cov = (S.coverage.rows || []).find((r) => r.patternId === p.id);
    const reg = cov ? cov.registered : 0;
    const status = reg === 0
      ? '<span class="chip chip-warn">未登録</span>'
      : reg >= p.target
        ? '<span class="chip chip-ok">完成</span>'
        : `<span class="chip chip-sea">${reg}/${p.target}</span>`;
    return `
      <div class="pattern-row">
        <div class="pattern-main">
          <div class="pattern-name">${esc(p.name)}</div>
          <div class="pattern-desc">${esc(p.description)}</div>
          <div class="tag-row" style="margin-top:6px">
            ${p.skills.slice(0, 3).map((s) => `<span class="chip" style="font-size:.64rem">${esc(s)}</span>`).join('')}
            ${p.examTypes.slice(0, 2).map((s) => `<span class="chip chip-gold" style="font-size:.64rem">${esc(s)}</span>`).join('')}
          </div>
        </div>
        <div style="text-align:right">
          ${status}
          <div style="margin-top:8px"><button class="btn btn-sm" data-practice="${esc(p.id)}">演習</button></div>
        </div>
      </div>`;
  }).join('');

  return `
    <article class="unit">
      <button class="unit-head">
        <div style="text-align:left">
          <div class="unit-name">${esc(u.name)}</div>
          <div class="unit-sub">${u.patterns.length} パターン</div>
        </div>
        <svg class="chev" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 3l5 5-5 5"/></svg>
      </button>
      <div class="unit-body">
        <div class="unit-meta">
          <div><h5>学習目標</h5><p>${esc(u.goal)}</p></div>
          <div><h5>前提知識</h5><p>${esc(u.prerequisites.join(' / ') || '—')}</p></div>
          <div><h5>重要語句・公式</h5><div class="tag-row">${u.keywords.map((k) => `<span class="chip" style="font-size:.66rem">${esc(k)}</span>`).join('')}</div></div>
          <div><h5>考え方</h5><p>${esc(u.approach)}</p></div>
        </div>
        ${rows}
      </div>
    </article>`;
}

// ------------------------------------------------------------------ PRACTICE
async function viewPractice(el) {
  setCrumbs(['演習・添削']);
  const patternId = S.params.pattern;
  const qid = S.params.id;

  if (qid && S.current && S.current.question && S.current.question.id === qid) return renderQuestionView(el);
  if (qid) return loadQuestion(el, qid);
  if (patternId) return renderPatternQuestions(el, patternId);
  return renderPatternPicker(el);
}

function renderPatternPicker(el) {
  const subs = S.curriculum.subjects.map((s) => {
    const k = SUBJECT_KEY[s.name];
    return `<button class="tab ${(!S.params.subject && k === 'jp') || S.params.subject === k ? 'active' : ''}" data-subj="${k}">${esc(s.name)}</button>`;
  }).join('');
  const subjectKey = S.params.subject || 'jp';
  const rows = (S.coverage.rows || []).filter((r) => r.subjectId === subjectKey);

  el.innerHTML = `
    <h1 class="serif" style="font-size:1.65rem;margin:0 0 6px">演習・添削</h1>
    <p style="color:var(--ink-2);font-size:.88rem;max-width:760px">
      問題パターンを選ぶと、登録済みの問題と難易度が表示されます。答えに至る根拠まで書いて提出してください。
    </p>
    <div style="display:flex;gap:10px;margin:18px 0;flex-wrap:wrap;align-items:center">
      <input type="text" id="pattern-search" placeholder="単元・パターン・スキルで検索（例: 二次関数, 条件付き確率）" style="max-width:420px" />
      <span class="chip" id="search-count"></span>
    </div>
    <div class="tabs">${subs}</div>
    <div id="pattern-list"></div>
  `;

  const draw = (filter = '') => {
    const f = filter.trim().toLowerCase();
    const list = rows
      .filter((r) => !f || r.patternName.toLowerCase().includes(f) || r.unitName.toLowerCase().includes(f) || r.description.toLowerCase().includes(f) || r.skills.some((s) => s.toLowerCase().includes(f)))
      .filter((r) => r.registered > 0 || !f);
    $('#search-count').textContent = `${list.filter((r) => r.registered > 0).length} パターンに問題あり`;
    $('#pattern-list').innerHTML = list.length
      ? list.map((r) => `
        <div class="pattern-row" style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin-bottom:8px">
          <div class="pattern-main">
            <div class="pattern-desc">${esc(r.courseName)} / ${esc(r.unitName)}</div>
            <div class="pattern-name">${esc(r.patternName)}</div>
            <div class="pattern-desc">${esc(r.description)}</div>
          </div>
          <div style="text-align:right;min-width:88px">
            <div class="pattern-count"><b>${r.registered}</b> / ${r.target} 問</div>
            <div style="margin-top:6px">
              ${r.registered > 0
                ? `<button class="btn btn-sm btn-primary" data-open="${esc(r.patternId)}">開く</button>`
                : `<button class="btn btn-sm" data-gen="${esc(r.patternId)}">AI生成</button>`}
            </div>
          </div>
        </div>`).join('')
      : '<div class="empty"><div class="big">該当なし</div><div>別のキーワードで検索してください。</div></div>';
    $$('[data-open]', el).forEach((b) => b.addEventListener('click', () => { location.hash = `#/practice?pattern=${encodeURIComponent(b.dataset.open)}`; }));
    $$('[data-gen]', el).forEach((b) => b.addEventListener('click', () => openGenerateModal(b.dataset.gen)));
  };
  $('#pattern-search').addEventListener('input', (e) => draw(e.target.value));
  $$('.tab', el).forEach((t) => t.addEventListener('click', () => { location.hash = `#/practice?subject=${t.dataset.subj}`; }));
  draw();
}

async function renderPatternQuestions(el, patternId) {
  el.innerHTML = '<div class="skeleton" style="height:200px"></div>';
  let data;
  try {
    data = await api(`/api/patterns/${encodeURIComponent(patternId)}`);
  } catch (e) {
    el.innerHTML = `<div class="notice notice-bad"><span class="ico">!</span><div>パターンが見つかりません。<br>${esc(e.message)}</div></div>`;
    return;
  }
  const { pattern, unit, questions, coverage } = data;
  setCrumbs(['演習', pattern.courseName, pattern.patternName]);

  const diffOrder = ['基礎', '応用', '発展', '複合・最難関'];
  el.innerHTML = `
    <div class="eyebrow">${esc(pattern.subjectName)} / ${esc(pattern.courseName)}</div>
    <h1 class="serif" style="font-size:1.55rem;margin:6px 0 8px">${esc(pattern.patternName)}</h1>
    <p style="color:var(--ink-2);font-size:.88rem;max-width:800px">${esc(pattern.description)}</p>

    <div class="grid grid-4" style="margin:20px 0">
      <div class="stat-tile"><div class="k">REGISTERED</div><div class="v">${coverage.registered}<small> / ${pattern.target} 問</small></div></div>
      <div class="stat-tile"><div class="k">VERIFIED</div><div class="v">${coverage.verified}<small> 問</small></div></div>
      <div class="stat-tile"><div class="k">基礎 / 応用</div><div class="v">${coverage.byDifficulty['基礎']}<small> / ${coverage.byDifficulty['応用']}</small></div></div>
      <div class="stat-tile"><div class="k">発展 / 複合</div><div class="v">${coverage.byDifficulty['発展']}<small> / ${coverage.byDifficulty['複合・最難関']}</small></div></div>
    </div>

    ${unit ? `
      <section class="card card-quiet" style="margin-bottom:18px">
        <div class="card-title"><h3>${esc(unit.name)}</h3><span class="eyebrow">UNIT</span></div>
        <p style="font-size:.82rem;color:var(--ink-2);margin-bottom:8px"><b>学習目標</b>　${esc(unit.goal)}</p>
        <p style="font-size:.82rem;color:var(--ink-2);margin-bottom:8px"><b>前提知識</b>　${esc(unit.prerequisites.join(' / ') || '—')}</p>
        <p style="font-size:.82rem;color:var(--ink-2);margin-bottom:0"><b>考え方</b>　${esc(unit.approach)}</p>
      </section>` : ''}

    <div class="rule-fancy"><span class="mono">QUESTIONS</span></div>

    ${questions.length ? questions.map((q) => `
      <div class="pattern-row" style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:14px 16px;margin-bottom:8px">
        <div class="pattern-main">
          <div class="pattern-desc"><span class="q-id">${esc(q.id)}</span> · ${esc(q.examType)} · ${esc(q.answerFormat)}</div>
          <div class="pattern-name" style="font-size:.86rem;line-height:1.7">${esc(q.prompt.slice(0, 96))}${q.prompt.length > 96 ? '…' : ''}</div>
        </div>
        <div style="text-align:right;min-width:80px">
          <span class="chip ${q.difficulty === '基礎' ? 'chip-ok' : q.difficulty === '応用' ? 'chip-sea' : 'chip-gold'}">${esc(q.difficulty)}</span>
          <div style="margin-top:8px"><button class="btn btn-sm btn-primary" data-q="${esc(q.id)}">解く</button></div>
        </div>
      </div>`).join('') : `
      <div class="notice notice-warn">
        <span class="ico">!</span>
        <div>
          このパターンの問題はまだ登録されていません（0 / ${pattern.target} 問）。
          <br>問題数だけを埋めるための水増しは行いません。AI生成で下書きを作り、内容を確認してから使ってください。
          <div style="margin-top:10px"><button class="btn btn-sm btn-brass" id="gen-here">AI生成で下書きを作る</button></div>
        </div>
      </div>`}

    <div style="margin-top:22px;display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn btn-sm" data-back>← パターン一覧</button>
      <button class="btn btn-sm" data-gen="${esc(pattern.patternId)}">このパターンでAI生成</button>
    </div>
  `;

  $$('[data-q]', el).forEach((b) => b.addEventListener('click', () => { location.hash = `#/practice/${encodeURIComponent(b.dataset.q)}`; }));
  $('[data-back]', el).addEventListener('click', () => { location.hash = `#/practice?subject=${pattern.subjectId}`; });
  const gen = $('[data-gen]', el); if (gen) gen.addEventListener('click', () => openGenerateModal(pattern.patternId));
  const gh = $('#gen-here', el); if (gh) gh.addEventListener('click', () => openGenerateModal(pattern.patternId));
  renderMath(el);
}

async function loadQuestion(el, qid) {
  el.innerHTML = '<div class="skeleton" style="height:240px"></div>';
  try {
    const { question } = await api(`/api/questions/${encodeURIComponent(qid)}`);
    S.current = {
      question,
      revealed: false,
      result: null,
      hintsShown: 0,
      startedAt: Date.now(),
      selected: '',
      reasoning: {},
    };
    renderQuestionView(el);
  } catch (e) {
    el.innerHTML = `<div class="notice notice-bad"><span class="ico">!</span><div>問題を読み込めませんでした。<br>${esc(e.message)}</div></div>`;
  }
}

const REASONING_FIELDS = [
  { key: 'grasp', label: '問題の把握', hint: '何を求める／説明する問題か' },
  { key: 'conditions', label: '条件の整理', hint: '与えられている情報は何か' },
  { key: 'evidence', label: '着目した根拠', hint: 'どの語句・数値・条件・文法・法則に注目したか' },
  { key: 'policy', label: '方針の決定', hint: 'なぜその公式・文法・解釈を選んだか' },
  { key: 'steps', label: '推論・解法', hint: 'どの順序で考えを進めたか' },
  { key: 'verify', label: '検証', hint: '条件に合うか、計算・文法に誤りはないか' },
];

function reasoningFieldsFor(q) {
  if (S.settings.detailLevel === 'brief') return REASONING_FIELDS.slice(0, 2);
  if (q.answerFormat === '選択式' || q.answerFormat === '穴埋め式') return REASONING_FIELDS.filter((f) => ['evidence', 'policy'].includes(f.key));
  return REASONING_FIELDS;
}

function renderQuestionView(el) {
  const st = S.current;
  const q = st.question;
  const diffCls = q.difficulty === '基礎' ? 'chip-ok' : q.difficulty === '応用' ? 'chip-sea' : 'chip-gold';
  const val = VALIDATION_LABEL[q.validation] || VALIDATION_LABEL.sample_unverified;
  setCrumbs(['演習', q.course, q.id]);

  const fields = reasoningFieldsFor(q);
  el.innerHTML = `
    <div class="practice-grid">
      <div>
        <article class="q-card">
          <div class="q-head">
            <span class="q-id">${esc(q.id)}</span>
            <span class="chip ${diffCls}">${esc(q.difficulty)}</span>
            <span class="chip chip-gold">${esc(q.examType)}</span>
            <span class="chip">${esc(q.answerFormat)}</span>
            <span class="chip ${val.c}">${val.t}</span>
            ${st.remaining ? `<span class="chip chip-bad" id="timer">残り ${st.remaining}s</span>` : ''}
          </div>
          <div class="q-body">
            <div class="q-prompt">${esc(q.prompt)}</div>
            ${q.passage ? `<div class="passage">${esc(q.passage)}</div>` : ''}
            ${q.dataTable ? renderTable(q.dataTable) : ''}
            ${q.choices ? renderChoices(q) : ''}

            <div class="reasoning-block" id="answer-area">
              ${q.choices ? '' : `
                <div class="reasoning-row">
                  <label>解答${S.settings.answerLanguage === 'en' ? '（English も可）' : ''}</label>
                  <textarea id="answer-input" rows="4" placeholder="結論を書いてください。数式は $x^2$ のように入力できます。">${esc(st.draftAnswer || '')}</textarea>
                </div>`}
            </div>

            ${S.settings.learningMode === 'timed' ? '' : `
            <div class="reasoning-block">
              <div class="eyebrow" style="margin-bottom:10px">思考の航路（任意・書くほど評価が上がります）</div>
              ${fields.map((f) => `
                <div class="reasoning-row">
                  <label>${f.label}<span class="hint-tag">${f.hint}</span></label>
                  <textarea data-reason="${f.key}" rows="2" placeholder="簡潔に">${esc((st.reasoning && st.reasoning[f.key]) || '')}</textarea>
                </div>`).join('')}
            </div>`}

            <div class="q-actions">
              <button class="btn btn-primary" id="submit-btn">提出して採点</button>
              <button class="btn" id="hint-btn">ヒント（${st.hintsShown}/3）</button>
              <button class="btn btn-ghost" id="ai-grade-btn" title="AIで根拠まで添削">AI添削</button>
              <button class="btn btn-ghost" id="next-btn" style="margin-left:auto">次の問題 →</button>
            </div>
          </div>
        </article>
        <div id="result-area"></div>
      </div>

      <aside>
        <div class="side-card">
          <h5>HINT</h5>
          <div class="hint-list" id="hint-list">
            ${st.hintsShown === 0
              ? '<div class="hint-locked">まだヒントは開いていません</div>'
              : Array.from({ length: st.hintsShown }, (_, i) => `<div class="hint-item">${esc(q.hints[i] || '—')}</div>`).join('')}
          </div>
        </div>
        <div class="side-card">
          <h5>PREREQUISITES</h5>
          <div class="tag-row">${(q.prerequisites || []).map((p) => `<span class="chip" style="font-size:.66rem">${esc(p)}</span>`).join('') || '<span class="chip">—</span>'}</div>
        </div>
        ${S.settings.showReferencedUnits === 'before' && q.relatedPatterns && q.relatedPatterns.length ? `
        <div class="side-card">
          <h5>RELATED UNITS</h5>
          ${q.relatedPatterns.map((p) => `<div style="font-size:.76rem;margin-bottom:5px">${esc(p)}</div>`).join('')}
        </div>` : ''}
        <div class="side-card">
          <h5>SESSION</h5>
          <div style="font-size:.76rem;color:var(--ink-3);line-height:1.9">
            モード: ${esc(modeLabel(S.settings.learningMode))}<br>
            詳細度: ${esc(detailLabel(S.settings.detailLevel))}<br>
            解答言語: ${esc(langLabel(S.settings.answerLanguage))}
          </div>
          <button class="btn btn-sm btn-block" style="margin-top:12px" data-goto="#/settings">設定を変える</button>
        </div>
      </aside>
    </div>
  `;

  $$('[data-reason]', el).forEach((t) => t.addEventListener('input', () => { S.current.reasoning[t.dataset.reason] = t.value; }));
  const ai = $('#answer-input', el); if (ai) ai.addEventListener('input', () => { S.current.draftAnswer = ai.value; });
  $$('.choice', el).forEach((c) => c.addEventListener('click', () => {
    $$('.choice', el).forEach((x) => x.classList.remove('sel'));
    c.classList.add('sel');
    S.current.selected = c.dataset.label;
  }));
  if (S.current.selected) { const c = $(`.choice[data-label="${S.current.selected}"]`, el); if (c) c.classList.add('sel'); }

  $('#submit-btn', el).addEventListener('click', () => submitAnswer(false));
  $('#ai-grade-btn', el).addEventListener('click', () => submitAnswer(true));
  $('#hint-btn', el).addEventListener('click', showHint);
  $('#next-btn', el).addEventListener('click', goNextQuestion);
  wireGoto(el);
  renderMath(el);
  if (st.remaining) startTimer();
}

function renderTable(t) {
  return `<table class="data-table"><caption>${esc(t.caption)}</caption>
    <thead><tr>${t.head.map((h) => `<th>${esc(h)}</th>`).join('')}</tr></thead>
    <tbody>${t.rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join('')}</tr>`).join('')}</tbody>
  </table>`;
}

function renderChoices(q) {
  return `<div class="choices">${q.choices.map((c) => `
    <button class="choice" data-label="${esc(c.label)}">
      <span class="lab">${esc(c.label)}</span>
      <span>${esc(c.text)}</span>
    </button>`).join('')}</div>`;
}

const modeLabel = (m) => ({ normal: '通常演習', hint: 'ヒントあり', explain: '解答後詳解', review: '苦手復習', timed: '時間制限' }[m] || m);
const detailLabel = (d) => ({ brief: '簡潔', detail: '詳細', grounds: '根拠・判断理由まで', alternatives: '別解・反例まで' }[d] || d);
const langLabel = (l) => ({ ja: '日本語', en: 'English', per_question: '問題ごと' }[l] || l);

async function showHint() {
  const st = S.current;
  if (st.hintsShown >= 3) { toast('ヒントは3段階までです'); return; }
  const next = st.hintsShown + 1;
  st.hintsShown = next;
  const q = st.question;
  if (q.hints && q.hints[next - 1]) {
    $('#hint-list').innerHTML = Array.from({ length: st.hintsShown }, (_, i) => `<div class="hint-item">${esc(q.hints[i] || '—')}</div>`).join('');
    $('#hint-btn').textContent = `ヒント（${st.hintsShown}/3）`;
    return;
  }
  $('#hint-list').insertAdjacentHTML('beforeend', '<div class="hint-locked">AIがヒントを作成中…</div>');
  try {
    const r = await api('/api/hint', {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...aiHeaders() },
      body: JSON.stringify({ questionId: q.id, level: next }),
    });
    $('#hint-list').innerHTML = Array.from({ length: st.hintsShown - 1 }, (_, i) => `<div class="hint-item">${esc(q.hints[i] || '—')}</div>`).join('')
      + `<div class="hint-item">${esc(r.hint)}</div>`;
    $('#hint-btn').textContent = `ヒント（${st.hintsShown}/3）`;
  } catch (e) {
    $('#hint-list').innerHTML = `<div class="hint-locked">ヒントを取得できませんでした</div>`;
    toast(e.message);
  }
}

let timerHandle = null;
function startTimer() {
  clearInterval(timerHandle);
  timerHandle = setInterval(() => {
    const st = S.current;
    if (!st || !st.remaining) { clearInterval(timerHandle); return; }
    st.remaining -= 1;
    const t = document.getElementById('timer');
    if (t) t.textContent = `残り ${st.remaining}s`;
    if (st.remaining <= 0) { clearInterval(timerHandle); toast('制限時間です。採点します'); submitAnswer(false); }
  }, 1000);
}

async function submitAnswer(useAi) {
  const st = S.current;
  if (!st || st.busy) return;
  const q = st.question;
  const answer = q.choices ? st.selected : ($('#answer-input') ? $('#answer-input').value : '');
  if (!answer && !Object.values(st.reasoning || {}).some(Boolean)) {
    toast(q.choices ? '選択肢を選んでください' : '解答を入力してください');
    return;
  }
  st.busy = true;
  const btn = $('#submit-btn');
  if (btn) { btn.disabled = true; btn.textContent = '採点中…'; }
  const elapsed = Date.now() - (st.startedAt || Date.now());

  try {
    const result = await api('/api/grade', {
      method: 'POST',
      headers: { 'content-type': 'application/json', ...aiHeaders() },
      body: JSON.stringify({
        questionId: q.id,
        answer,
        reasoning: st.reasoning,
        mode: S.settings.learningMode,
        elapsedMs: elapsed,
        hintCount: st.hintsShown,
        useAi: Boolean(useAi),
        language: S.settings.answerLanguage === 'en' ? 'en' : 'ja',
      }),
    });
    st.result = result;
    st.revealed = true;
    renderResult(result, useAi);
    saveAttempt(q, answer, result, elapsed);
    toast(result.aiError ? 'ルーブリック採点を表示しました（AI未使用）' : '採点しました');
  } catch (e) {
    toast(e.message);
  } finally {
    st.busy = false;
    if (btn) { btn.disabled = false; btn.textContent = '提出して採点'; }
  }
}

function saveAttempt(q, answer, result, elapsed) {
  const rec = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    questionId: q.id,
    patternId: q.patternId,
    subject: q.subject,
    course: q.course,
    unit: q.unit,
    difficulty: q.difficulty,
    examType: q.examType,
    verdict: result.verdict,
    score: result.score,
    maxScore: result.maxScore,
    percent: result.percent,
    answer,
    reasoning: S.current.reasoning,
    rubric: result.rubric,
    errorTypes: result.errorTypes,
    elapsedMs: elapsed,
    hints: S.current.hintsShown,
    gradedBy: result.gradedBy,
    createdAt: new Date().toISOString(),
  };
  S.history.unshift(rec);
  saveHistory();
  if (S.route === 'home') return;
}

function renderResult(result, usedAi) {
  const q = S.current.question;
  const v = VERDICT[result.verdict] || VERDICT.partial;
  const pct = result.maxScore ? Math.round((result.score / result.maxScore) * 100) : 0;
  const circ = 2 * Math.PI * 44;
  const detail = S.settings.detailLevel;

  const rubricRows = result.rubric.map((r) => {
    const cls = r.points >= r.maxPoints ? 'full' : r.points > 0 ? 'part' : 'zero';
    return `<tr>
      <td>${esc(r.criterion)}</td>
      <td class="pts ${cls}">${r.points} / ${r.maxPoints}</td>
      <td style="font-size:.74rem;color:var(--ink-3)">${r.missing.length ? '不足: ' + esc(r.missing.join(' / ')) : r.points > 0 ? '要素を確認' : '未達'}</td>
    </tr>`;
  }).join('');

  const showSolution = S.settings.learningMode !== 'timed' || pct >= 60;

  $('#result-area').innerHTML = `
    <article class="q-card" style="margin-top:18px">
      <div class="q-body">
        <div class="result" style="border-top:0;padding-top:0;margin-top:0">
          <div class="score-band">
            <div class="score-ring">
              <svg width="104" height="104" viewBox="0 0 104 104">
                <circle cx="52" cy="52" r="44" fill="none" stroke="#ece6d8" stroke-width="8"/>
                <circle cx="52" cy="52" r="44" fill="none" stroke="${pct >= 80 ? '#2f7d5d' : pct >= 40 ? '#b4692b' : '#a63d3d'}"
                  stroke-width="8" stroke-linecap="round" stroke-dasharray="${circ}" stroke-dashoffset="${circ * (1 - pct / 100)}"/>
              </svg>
              <div class="val"><b>${result.score}</b><span>/ ${result.maxScore}</span></div>
            </div>
            <div>
              <div class="verdict">${v.label}
                <span class="chip ${v.cls}" style="margin-left:8px">${pct}%</span>
                ${result.gradedBy === 'rubric+ai' ? '<span class="chip chip-sea" style="margin-left:6px">AI添削</span>' : '<span class="chip" style="margin-left:6px">ルーブリック</span>'}
              </div>
              <div style="font-size:.82rem;color:var(--ink-3);max-width:520px">${v.note}</div>
            </div>
          </div>

          ${result.aiError ? `<div class="notice notice-warn" style="margin-top:16px"><span class="ico">!</span><div>${esc(result.aiError)}</div></div>` : ''}
          ${result.caution && detail !== 'brief' ? `<div class="notice notice-info" style="margin-top:12px"><span class="ico">i</span><div>${esc(result.caution)}</div></div>` : ''}

          <div class="rule"></div>
          <h4 class="serif" style="font-size:1rem;margin:0 0 6px">評価の内訳</h4>
          <table class="rubric-table">
            <thead><tr><th>評価項目</th><th>得点</th><th>状態</th></tr></thead>
            <tbody>${rubricRows}</tbody>
          </table>

          <div class="grid grid-2" style="margin-top:18px">
            ${result.strengths.length ? `<div class="feedback-block good"><h5>正しい部分</h5><ul>${result.strengths.map((s) => `<li>${esc(s)}</li>`).join('')}</ul></div>` : ''}
            ${result.gaps.length ? `<div class="feedback-block bad"><h5>不足している根拠・要素</h5><ul>${result.gaps.map((s) => `<li>${esc(s)}</li>`).join('')}</ul></div>` : ''}
          </div>

          ${result.logicGaps && result.logicGaps.length ? `<div class="feedback-block"><h5>論理のつながり・飛躍</h5><ul>${result.logicGaps.map((s) => `<li>${esc(s)}</li>`).join('')}</ul></div>` : ''}

          ${result.errorTypes && result.errorTypes.length ? `<div class="feedback-block"><h5>誤答の分類</h5><div class="tag-row">${result.errorTypes.map((e) => `<span class="chip chip-warn">${esc(ERROR_LABEL[e] || e)}</span>`).join('')}</div></div>` : ''}

          ${showSolution ? renderSolutions(q, detail, result) : ''}

          <div class="rule"></div>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <button class="btn btn-primary btn-sm" id="retry-btn">もう一度解く</button>
            ${q.relatedPatterns && q.relatedPatterns.length ? `<button class="btn btn-sm" data-related="${esc(q.relatedPatterns[0])}">類題のパターンへ</button>` : ''}
            <button class="btn btn-sm" id="next-btn2">次の問題へ</button>
          </div>
        </div>
      </div>
    </article>
  `;

  const rb = $('#retry-btn'); if (rb) rb.addEventListener('click', retryQuestion);
  const nb = $('#next-btn2'); if (nb) nb.addEventListener('click', goNextQuestion);
  const rel = $('[data-related]');
  if (rel) rel.addEventListener('click', () => { location.hash = `#/practice?pattern=${encodeURIComponent(rel.dataset.related)}`; });
  renderMath($('#result-area'));
  $('#result-area').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

const ERROR_LABEL = {
  calculation: '計算・単位',
  insufficient_grounds: '根拠説明の不足',
  answer_mismatch: '結論の不一致',
  grammar: '文法・語法',
  terminology: '用語の誤り',
  misreading: '読み取り違い',
  insufficient_description: '記述量の不足',
};

function renderSolutions(q, detail, result) {
  const blocks = [];
  if (S.settings.detailLevel !== 'brief') {
    blocks.push(`<div class="feedback-block gold"><h5>模範解答</h5><div style="font-size:.9rem;line-height:1.95">${esc(q.expectedAnswer)}</div>
      ${(q.acceptableAnswers || []).length ? `<div style="font-size:.76rem;color:var(--ink-3);margin-top:8px">許容される別解: ${esc(q.acceptableAnswers.join(' / '))}</div>` : ''}</div>`);
  }

  const showDetail = detail !== 'brief';
  if (showDetail && q.reasoningSteps && q.reasoningSteps.length) {
    blocks.push(`<div class="feedback-block"><h5>解法の手順（再現できる形で）</h5>
      <ol style="margin:0;padding-left:20px;font-size:.82rem;line-height:1.95">
        ${q.reasoningSteps.map((s) => `<li><b>${esc(s.purpose)}</b> — ${esc(s.explanation)}</li>`).join('')}
      </ol></div>`);
  }

  if (showDetail && q.evidence && q.evidence.length) {
    blocks.push(`<div class="feedback-block"><h5>根拠</h5>
      <ul style="font-size:.82rem">${q.evidence.map((e) => `<li><span class="mono" style="font-size:.66rem;color:var(--brass)">${esc(e.source)}</span><br>${esc(e.interpretation)}</li>`).join('')}</ul></div>`);
  }

  if (q.literalTranslation || q.naturalTranslation) {
    blocks.push(`<div class="feedback-block"><h5>訳の比較</h5>
      ${q.literalTranslation ? `<div style="font-size:.84rem;margin-bottom:6px"><b>直訳</b>　${esc(q.literalTranslation)}</div>` : ''}
      ${q.naturalTranslation ? `<div style="font-size:.84rem"><b>自然な訳</b>　${esc(q.naturalTranslation)}</div>` : ''}</div>`);
  }

  if (q.choices) {
    blocks.push(`<div class="feedback-block"><h5>選択肢ごとの判定</h5>
      <ul style="font-size:.8rem">${q.choices.map((c) => `<li><b>${esc(c.label)}. ${c.correct ? '正解' : '誤り'}</b> — ${esc(c.why || '')}</li>`).join('')}</ul></div>`);
  }

  if (showDetail && q.solution && q.solution.length) {
    const sections = q.solution.map((s) => `<div class="solution-section"><h5>${esc(s.title)}</h5><p>${esc(s.body)}</p></div>`).join('');
    blocks.push(`<div class="feedback-block"><h5>詳細解説</h5>${sections}</div>`);
  }

  if (q.commonErrors && q.commonErrors.length) {
    blocks.push(`<div class="feedback-block bad"><h5>よくある誤答と原因</h5>
      <ul style="font-size:.82rem">${q.commonErrors.map((e) => `<li>「${esc(e.error)}」<br><span style="color:var(--ink-3)">原因: ${esc(e.reason)}</span></li>`).join('')}</ul></div>`);
  }

  if (result && result.improvedAnswer && detail === 'alternatives') {
    blocks.push(`<div class="feedback-block gold"><h5>改善した解答例</h5><div style="font-size:.88rem;white-space:pre-wrap">${esc(result.improvedAnswer)}</div></div>`);
  }

  if (q.relatedPatterns && q.relatedPatterns.length) {
    blocks.push(`<div class="feedback-block"><h5>次に解くべき類題</h5><div class="tag-row">${q.relatedPatterns.map((p) => `<span class="chip">${esc(p)}</span>`).join('')}</div></div>`);
  }

  return blocks.join('');
}

function retryQuestion() {
  const st = S.current;
  st.revealed = false;
  st.result = null;
  st.hintsShown = 0;
  st.selected = '';
  st.draftAnswer = '';
  st.reasoning = {};
  st.startedAt = Date.now();
  $('#result-area').innerHTML = '';
  renderQuestionView($('#view'));
}

async function goNextQuestion() {
  const st = S.current;
  if (!st) return;
  try {
    const { question } = await api(`/api/patterns/${encodeURIComponent(st.question.patternId)}`);
    const idx = question.questions.findIndex((x) => x.id === st.question.id);
    const next = question.questions[(idx + 1) % question.questions.length];
    if (next && next.id !== st.question.id) { location.hash = `#/practice/${encodeURIComponent(next.id)}`; }
    else { location.hash = `#/practice?pattern=${encodeURIComponent(st.question.patternId)}`; }
  } catch {
    location.hash = '#/practice';
  }
}

// ------------------------------------------------------------------ AI generate
function openGenerateModal(patternId) {
  const row = (S.coverage.rows || []).find((r) => r.patternId === patternId);
  const modal = document.createElement('div');
  modal.className = 'modal-back';
  modal.innerHTML = `
    <div class="modal">
      <div class="eyebrow">AI DRAFT</div>
      <h2 class="serif" style="margin:6px 0 6px;font-size:1.2rem">問題の下書きを生成</h2>
      <p style="font-size:.82rem;color:var(--ink-3)">${esc(row ? row.courseName + ' / ' + row.unitName + ' / ' + row.patternName : patternId)}</p>
      <div class="notice notice-warn" style="margin:14px 0">
        <span class="ico">!</span>
        <div>AI生成問題は<b>未検証</b>として扱われます。模範解答・採点基準を必ず確認してください。生成した問題はこの端末に保存されます。</div>
      </div>
      <div class="grid grid-2">
        <div><label class="mono" style="font-size:.6rem">難易度</label>
          <select id="gen-diff"><option>基礎</option><option selected>応用</option><option>発展</option><option>複合・最難関</option></select></div>
        <div><label class="mono" style="font-size:.6rem">出題形式</label>
          <select id="gen-exam"><option>定期考査型</option><option selected>共通テスト型</option><option>国公立二次型</option><option>私立大型</option><option>横断型</option></select></div>
      </div>
      <div style="display:flex;gap:10px;justify-content:flex-end;margin-top:20px">
        <button class="btn" data-close>閉じる</button>
        <button class="btn btn-brass" id="gen-run">生成する</button>
      </div>
      <div id="gen-out" style="margin-top:16px"></div>
    </div>`;
  document.body.appendChild(modal);
  modal.addEventListener('click', (e) => { if (e.target === modal || e.target.hasAttribute('data-close')) modal.remove(); });
  $('#gen-run', modal).addEventListener('click', async () => {
    const out = $('#gen-out', modal);
    out.innerHTML = '<div class="skeleton" style="height:80px"></div>';
    try {
      const r = await api('/api/generate', {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...aiHeaders() },
        body: JSON.stringify({ patternId, difficulty: $('#gen-diff').value, examType: $('#gen-exam').value }),
      });
      const saved = loadGenerated();
      saved.unshift(r.question);
      localStorage.setItem('chishin.generated.v1', JSON.stringify(saved.slice(0, 60)));
      out.innerHTML = `
        <div class="notice notice-info"><span class="ico">✓</span><div>生成しました（${esc(r.model)}）。<b>未検証</b>のため、内容を確認してから使ってください。</div></div>
        <div style="margin-top:12px;font-size:.86rem;line-height:1.9">${esc(r.question.prompt)}</div>
        <div style="margin-top:10px;font-size:.8rem;color:var(--ink-3)"><b>模範解答:</b> ${esc(r.question.expectedAnswer)}</div>
        <div style="margin-top:14px"><button class="btn btn-sm btn-primary" id="gen-open">この問題を解く</button></div>`;
      $('#gen-open', modal).addEventListener('click', () => {
        S.current = { question: r.question, revealed: false, result: null, hintsShown: 0, startedAt: Date.now(), selected: '', reasoning: {} };
        modal.remove();
        location.hash = `#/practice/${encodeURIComponent(r.question.id)}`;
        renderQuestionView($('#view'));
      });
      renderMath(out);
    } catch (e) {
      out.innerHTML = `<div class="notice notice-bad"><span class="ico">!</span><div>${esc(e.message)}</div></div>`;
    }
  });
}

function loadGenerated() {
  try { return JSON.parse(localStorage.getItem('chishin.generated.v1') || '[]'); } catch { return []; }
}
