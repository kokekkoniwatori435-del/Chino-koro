/* ============================================================================
   知の航路 — AI クライアント（Gemini）
   優先順位:
     1) Cloudflare Worker のプロキシ（/api/ai/*）… キーはサーバー側 secret
     2) ブラウザに保存されたキー（設定画面で入力）… 端末内のみ
   どちらも使えない場合は「AI 未設定」としてルーブリック採点のみで動作する。
   ========================================================================== */
'use strict';

window.CHISHIN_AI = (function () {
  const KEY_LS = 'chishin.geminiKey.v1';
  const MODELS = ['gemini-2.5-flash', 'gemini-2.5-flash-lite', 'gemini-2.0-flash'];

  const state = {
    checked: false,
    server: false,
    model: null,
    models: [],
  };

  function browserKey() {
    try { return localStorage.getItem(KEY_LS) || ''; } catch { return ''; }
  }

  function available() {
    return state.server || Boolean(browserKey());
  }

  function mode() {
    if (state.server) return 'server';
    if (browserKey()) return 'browser';
    return 'none';
  }

  async function check() {
    try {
      const res = await fetch('/api/health', { headers: { accept: 'application/json' } });
      if (res.ok) {
        const h = await res.json();
        state.server = Boolean(h && h.ai);
        state.model = h && h.model;
        state.models = (h && h.models) || [];
      } else {
        state.server = false;
      }
    } catch {
      state.server = false;
    }
    state.checked = true;
    return { server: state.server, browser: Boolean(browserKey()), model: state.model, mode: mode() };
  }

  /** 生テキストを得る（JSON 文字列を含む） */
  async function raw(system, user, opts) {
    const o = opts || {};
    await (state.checked ? Promise.resolve() : check());

    if (state.server) {
      const res = await fetch('/api/ai/generate', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          system,
          user,
          temperature: o.temperature,
          maxOutputTokens: o.maxOutputTokens,
          thinkingBudget: o.thinkingBudget,
          json: o.json,
        }),
      });
      const data = await safeJson(res);
      if (!res.ok) {
        const err = new Error((data && data.error) || `AI ${res.status}`);
        err.status = res.status;
        throw err;
      }
      return { text: data.text, model: data.model, via: 'server' };
    }

    const key = browserKey();
    if (!key) {
      const err = new Error('AIキーが未設定です。設定画面で Gemini API キーを入力してください。');
      err.status = 503;
      throw err;
    }

    let lastErr = null;
    const list = state.models.length ? state.models : MODELS;
    for (const model of list.slice(0, 3)) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), o.timeoutMs || 55000);
      try {
        const generationConfig = {
          temperature: o.temperature == null ? 0.4 : o.temperature,
          maxOutputTokens: Math.min(o.maxOutputTokens || 4096, 8192),
        };
        if (o.json !== false) generationConfig.responseMimeType = 'application/json';
        if (o.thinkingBudget != null) generationConfig.thinkingConfig = { thinkingBudget: o.thinkingBudget };

        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
          {
            method: 'POST',
            headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
            signal: ctrl.signal,
            body: JSON.stringify({
              systemInstruction: { parts: [{ text: system }] },
              contents: [{ role: 'user', parts: [{ text: user }] }],
              generationConfig,
            }),
          }
        );
        if (!res.ok) {
          const detail = await res.text();
          lastErr = new Error(`Gemini ${res.status}: ${detail.slice(0, 200)}`);
          if (res.status === 400 && /API key/i.test(detail)) {
            throw new Error('Gemini API キーが正しくありません。設定を確認してください。');
          }
          continue;
        }
        const json = await res.json();
        const parts = (json.candidates && json.candidates[0] && json.candidates[0].content && json.candidates[0].content.parts) || [];
        const text = parts.map((p) => p.text || '').join('');
        if (!text) { lastErr = new Error('Gemini が空の応答を返しました'); continue; }
        return { text, model, via: 'browser' };
      } catch (e) {
        if (e && e.name === 'AbortError') { lastErr = new Error('AIの応答がタイムアウトしました'); continue; }
        if (e && /API key/.test(e.message || '')) throw e;
        lastErr = e;
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastErr || new Error('Gemini API に接続できませんでした');
  }

  async function safeJson(res) {
    const text = await res.text();
    try { return text ? JSON.parse(text) : {}; } catch { return { raw: text }; }
  }

  /** JSON 応答をゆるく復元（LaTeX エスケープ事故対策） */
  function parseJson(text) {
    const cleaned = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/, '').trim();
    try { return JSON.parse(cleaned); } catch { /* repair */ }
    const s = cleaned.indexOf('{');
    const t = cleaned.lastIndexOf('}');
    if (s < 0 || t <= s) throw new Error('AI応答をJSONとして解釈できませんでした');
    const body = cleaned.slice(s, t + 1);
    try { return JSON.parse(body); } catch { /* repair */ }
    try { return JSON.parse(body.replace(/\\(?!["\\/bfnrtu])/g, '\\\\')); } catch {
      throw new Error('AI応答をJSONとして解釈できませんでした');
    }
  }

  async function json(system, user, opts) {
    const { text, model, via } = await raw(system, user, opts);
    return { data: parseJson(text), model, via };
  }

  return { check, available, mode, raw, json, parseJson, state, browserKey, MODELS };
})();
