/* 自動生成: scripts/gen/build.js — 手で編集しないでください */
(window.CHISHIN_Q = window.CHISHIN_Q || {})["en-structure"] = [];
