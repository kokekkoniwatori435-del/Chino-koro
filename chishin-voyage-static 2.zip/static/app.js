/* ============================================================================
   知の航路 | THE VOYAGE OF KNOWLEDGE — SPA
   Vanilla JS / no build step. Data: /api/*, persistence: localStorage,
   optional AI: server env key or browser-held key (never sent anywhere else).
   ========================================================================== */
'use strict';

// ------------------------------------------------------------------ state
const LS = {
  settings: 'chishin.settings.v1',
  history: 'chishin.history.v1',
  gemini: 'chishin.geminiKey.v1',
  bookmarks: 'chishin.bookmarks.v1',
};

const DEFAULT_SETTINGS = {
  answerLanguage: 'ja',          // ja | en | per_question
  answerFormat: 'auto',          // auto | 選択式 | 記述式 | 証明・論証式 | ...
  detailLevel: 'grounds',        // brief | detail | grounds | alternatives
  learningMode: 'normal',        // normal | hint | explain | review | timed
  showReferencedUnits: 'after',  // after | before  (融合問題の単元表示)
  timerEnabled: false,
};

const S = {
  route: 'home',
  params: {},
  curriculum: null,
  coverage: null,
  settings: loadJSON(LS.settings, DEFAULT_SETTINGS),
  history: loadJSON(LS.history, []),
  geminiKey: localStorage.getItem(LS.gemini) || '',
  current: null,      // { question, pattern, revealed, hintsShown, result, startedAt }
  loading: false,
};

function loadJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return typeof fallback === 'object' && !Array.isArray(fallback) ? { ...fallback, ...parsed } : parsed;
  } catch { return fallback; }
}
function saveSettings() { localStorage.setItem(LS.settings, JSON.stringify(S.settings)); }
function saveHistory() {
  // 直近200件に制限
  S.history = S.history.slice(0, 200);
  localStorage.setItem(LS.history, JSON.stringify(S.history));
}

// ------------------------------------------------------------------ utils
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const esc = (s) => String(s == null ? '' : s)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
const nl2br = (s) => esc(s).replace(/\n/g, '<br>');

function toast(msg, ms = 2400) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), ms);
}

/**
 * API ディスパッチャ。
 * 既定はブラウザ内のローカル実装（サーバー不要 / 静的ホスティング対応）。
 * ?server=1 を付けた場合のみ実サーバーの /api を叩く（Worker版で動作確認するとき用）。
 */
const USE_SERVER = new URLSearchParams(location.search).get('server') === '1';

async function api(path, opts) {
  if (!USE_SERVER && window.CHISHIN_API) {
    try {
      return await window.CHISHIN_API.request(path, opts);
    } catch (e) {
      const err = new Error(e && e.message ? e.message : '処理に失敗しました');
      err.status = (e && e.status) || 500;
      throw err;
    }
  }
  const res = await fetch(path, opts);
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text }; }
  if (!res.ok) {
    const msg = (data && (data.error || data.aiError)) || `HTTP ${res.status}`;
    const err = new Error(msg);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

function aiHeaders() {
  return S.geminiKey ? { 'x-gemini-key': S.geminiKey } : {};
}

function fmtDate(iso) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function renderMath(root) {
  if (typeof renderMathInElement !== 'function') return;
  try {
    renderMathInElement(root, {
      delimiters: [
        { left: '$$', right: '$$', display: true },
        { left: '$', right: '$', display: false },
        { left: '\\[', right: '\\]', display: true },
        { left: '\\(', right: '\\)', display: false },
      ],
      throwOnError: false,
      strict: false,
      trust: false,
    });
  } catch (e) { /* noop */ }
}

const VERDICT = {
  correct: { label: '到達', cls: 'chip-ok', note: '根拠まで含めて十分に説明できています。' },
  partial: { label: '部分到達', cls: 'chip-warn', note: '方向は合っていますが、根拠や要素に不足があります。' },
  incorrect: { label: '要再航海', cls: 'chip-bad', note: 'まず方針の立て直しから。ヒントを段階的に開いてみましょう。' },
  needs_review: { label: '要確認', cls: 'chip-sea', note: '自動判定では確定できません。模範解答と照合してください。' },
};

const VALIDATION_LABEL = {
  verified: { t: '内容確認済み', c: 'chip-ok' },
  auto_checked: { t: '自動検証済み', c: 'chip-sea' },
  sample_unverified: { t: '見本（未検証）', c: 'chip-warn' },
  ai_generated_unverified: { t: 'AI生成・未検証', c: 'chip-bad' },
};

const SUBJECT_KEY = { '国語': 'jp', '数学': 'math', '英語': 'en', '理科': 'sci', '地理': 'geo' };
const SUBJECT_COLOR = { jp: 'var(--s-jp)', math: 'var(--s-math)', en: 'var(--s-en)', sci: 'var(--s-sci)', geo: 'var(--s-geo)' };
const SUBJECT_EN = { 国語: 'JAPANESE', 数学: 'MATHEMATICS', 英語: 'ENGLISH', 理科: 'SCIENCE', 地理: 'GEOGRAPHY' };

// ------------------------------------------------------------------ bootstrap
async function boot() {
  $('#quick-print').addEventListener('click', () => window.print());
  window.addEventListener('popstate', () => { readHash(); route(); });
  wireSidebar();

  try {
    const [cur, cov] = await Promise.all([api('/api/curriculum'), api('/api/coverage')]);
    S.curriculum = cur;
    S.coverage = cov;
    renderSidebarCoverage();
  } catch (e) {
    $('#view').innerHTML = `<div class="notice notice-bad"><span class="ico">!</span><div>教材データの読み込みに失敗しました。<br>${esc(e.message)}</div></div>`;
    return;
  }

  readHash();
  route();
  checkAi();
}

function wireSidebar() {
  document.addEventListener('click', (e) => {
    const nav = e.target.closest('.nav-item');
    if (nav) { location.hash = '#/' + nav.dataset.route; return; }
  });
}

function readHash() {
  const h = (location.hash || '#/home').replace(/^#\/?/, '');
  const [path, query] = h.split('?');
  const parts = path.split('/').filter(Boolean);
  S.route = parts[0] || 'home';
  S.params = {};
  if (query) new URLSearchParams(query).forEach((v, k) => (S.params[k] = v));
  if (parts[1]) S.params.id = decodeURIComponent(parts[1]);
}

async function checkAi() {
  const chip = $('#ai-chip');
  try {
    const h = await api('/api/health');
    if (h.ai || S.geminiKey) {
      chip.className = 'chip chip-ok';
      chip.textContent = h.ai ? `AI 稼働 · ${h.model}` : 'AI 稼働 · ブラウザキー';
    } else {
      chip.className = 'chip chip-warn';
      chip.textContent = 'AI 未設定（採点はルーブリックのみ）';
    }
  } catch {
    chip.className = 'chip chip-bad';
    chip.textContent = 'AI 不明';
  }
}

function renderSidebarCoverage() {
  const sum = S.coverage && S.coverage.summary;
  if (!sum) return;
  const pct = sum.targetQuestions ? Math.round((sum.registeredQuestions / sum.targetQuestions) * 1000) / 10 : 0;
  $('#coverage-mini').innerHTML = `
    <div class="coverage-mini-row"><span>教材整備</span><span>${pct}%</span></div>
    <div class="bar"><span style="width:${Math.min(100, pct)}%"></span></div>
    <div class="coverage-mini-row" style="margin-top:8px"><span>登録 ${sum.registeredQuestions} 問</span><span>目標 ${sum.targetQuestions.toLocaleString()} 問</span></div>
  `;
}

// ------------------------------------------------------------------ router
function route() {
  $$('.nav-item').forEach((n) => n.classList.toggle('active', n.dataset.route === S.route));
  const view = $('#view');
  view.scrollTop = 0;
  window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });

  switch (S.route) {
    case 'home': return viewHome(view);
    case 'curriculum': return viewCurriculum(view);
    case 'practice': return viewPractice(view);
    case 'history': return viewHistory(view);
    case 'coverage': return viewCoverage(view);
    case 'settings': return viewSettings(view);
    case 'about': return viewAbout(view);
    default: return viewHome(view);
  }
}

function setCrumbs(parts) {
  $('#crumbs').innerHTML = parts.map((p, i) =>
    i === parts.length - 1 ? `<b>${esc(p)}</b>` : `${esc(p)} <span style="opacity:.4">/</span>`
  ).join(' ');
}

// ------------------------------------------------------------------ HOME
function viewHome(el) {
  const sum = S.coverage.summary;
  const recent = S.history.slice(0, 4);
  setCrumbs(['海図', 'ホーム']);

  const subjectCards = S.curriculum.subjects.map((s) => {
    const key = SUBJECT_KEY[s.name] || 'jp';
    const sub = sum.bySubject[s.name] || { patterns: 0, registered: 0, target: 0 };
    const courses = s.courses.length;
    const units = s.courses.reduce((a, c) => a + c.units.length, 0);
    return `
      <button class="subject-card" data-goto="#/curriculum?subject=${key}">
        <span class="bar-accent" style="background:${SUBJECT_COLOR[key]}"></span>
        <h4>${esc(s.name)}</h4>
        <div class="en">${SUBJECT_EN[s.name] || ''}</div>
        <div class="meta"><span><b>${courses}</b> 科目</span><span><b>${units}</b> 単元</span><span><b>${sub.patterns}</b> 型</span></div>
        <div class="meta" style="margin-top:6px;color:var(--ink-3)"><span>登録 <b>${sub.registered}</b> 問</span></div>
      </button>`;
  }).join('');

  el.innerHTML = `
    <section class="hero">
      <svg class="compass" viewBox="0 0 100 100" aria-hidden="true">
        <circle cx="50" cy="50" r="46" fill="none" stroke="#c9a65e" stroke-width="1"/>
        <circle cx="50" cy="50" r="34" fill="none" stroke="#c9a65e" stroke-width=".6"/>
        <path d="M50 6l5 39 39 5-39 5-5 39-5-39-39-5 39-5z" fill="#c9a65e" opacity=".55"/>
        <path d="M50 18l3.5 28.5L82 50l-28.5 3.5L50 82l-3.5-28.5L18 50l28.5-3.5z" fill="#f3eee1" opacity=".28"/>
      </svg>
      <div class="hero-en">THE VOYAGE OF KNOWLEDGE</div>
      <h1>知の航路</h1>
      <p class="hero-lead">
        正解を選ぶだけでは、入試は越えられません。この海図は、<b>条件を整理し、根拠を示し、解法を選び、別解と比較する</b>——
        その思考の航路そのものを記録し、添削する学習システムです。
      </p>
      <div class="hero-stats">
        <div class="hero-stat"><div class="v">${sum.subjects}<span style="font-size:.9rem">教科</span></div><div class="k">SUBJECTS</div></div>
        <div class="hero-stat"><div class="v">${sum.units}</div><div class="k">UNITS 単元</div></div>
        <div class="hero-stat"><div class="v">${sum.patterns}</div><div class="k">PATTERNS 問題パターン</div></div>
        <div class="hero-stat"><div class="v">${sum.registeredQuestions}</div><div class="k">QUESTIONS 登録済</div></div>
      </div>
    </section>

    <div class="rule-fancy"><span class="mono">CHART OF SUBJECTS</span></div>

    <div class="subject-grid">${subjectCards}</div>

    <div class="grid grid-2" style="margin-top:26px">
      <section class="card">
        <div class="card-title"><h3>学習の設計</h3><span class="eyebrow">METHOD</span></div>
        <p style="font-size:.86rem;color:var(--ink-2)">
          すべての問題に「問題把握 → 条件整理 → 着目した根拠 → 方針 → 推論 → 結論 → 検証 → 別解」の
          思考欄が用意されています。答えが合っていても根拠が欠けていれば満点になりません。
        </p>
        <div class="tag-row" style="margin-top:12px">
          <span class="chip chip-gold">根拠付き記述</span>
          <span class="chip">部分点評価</span>
          <span class="chip">別解許容</span>
          <span class="chip">誤答原因の分類</span>
        </div>
        <button class="btn btn-brass" style="margin-top:18px" data-goto="#/practice">演習をはじめる</button>
      </section>

      <section class="card">
        <div class="card-title"><h3>直近の航海</h3><span class="eyebrow">LOG</span></div>
        ${recent.length ? recent.map(histRowMini).join('') : `
          <div class="empty" style="padding:26px 10px">
            <div class="big">まだ記録がありません</div>
            <div>1問解くと、ここに到達度と弱点が並びます。</div>
          </div>`}
      </section>
    </div>

    <div class="notice notice-info" style="margin-top:22px">
      <span class="ico">i</span>
      <div>
        教材は「単元・問題パターンの一覧」と「実際に登録済みの問題数」を別々に管理しています。
        <a href="#/coverage">整備状況</a>で、未登録・未検証の範囲をいつでも確認できます。
      </div>
    </div>
  `;

  wireGoto(el);
  renderMath(el);
}

function histRowMini(a) {
  const v = VERDICT[a.verdict] || VERDICT.partial;
  return `
    <div class="hist-row" style="grid-template-columns:1fr auto">
      <div>
        <div>${esc(a.questionId)} · ${esc(a.difficulty || '')}</div>
        <div class="hist-meta">${esc(a.patternId || '')} · ${fmtDate(a.createdAt)}</div>
      </div>
      <span class="chip ${v.cls}">${a.score}/${a.maxScore}</span>
    </div>`;
}

function wireGoto(root) {
  $$('[data-goto]', root).forEach((b) => {
    b.addEventListener('click', () => { location.hash = b.dataset.goto; });
  });
}
