/* ============================================================================
   知の航路 — views: history / coverage / settings / about
   ========================================================================== */
'use strict';

// ------------------------------------------------------------------ HISTORY
function viewHistory(el) {
  setCrumbs(['航海日誌']);
  const h = S.history;

  if (!h.length) {
    el.innerHTML = `
      <h1 class="serif" style="font-size:1.65rem;margin:0 0 6px">航海日誌</h1>
      <div class="empty">
        <div class="big">まだ記録がありません</div>
        <div>1問解くと、到達度・弱点・誤答の分類がここに蓄積されます。</div>
        <div style="margin-top:18px"><button class="btn btn-primary" data-goto="#/practice">演習をはじめる</button></div>
      </div>`;
    wireGoto(el);
    return;
  }

  const total = h.length;
  const avg = Math.round(h.reduce((a, x) => a + (x.percent || 0), 0) / total);
  const perfect = h.filter((x) => x.verdict === 'correct').length;
  const needReview = h.filter((x) => (x.percent || 0) < 50).length;
  const last10 = h.slice(0, 10).reverse();

  // 誤答分類の集計
  const errCount = {};
  h.forEach((x) => (x.errorTypes || []).forEach((e) => { errCount[e] = (errCount[e] || 0) + 1; }));
  const errRows = Object.entries(errCount).sort((a, b) => b[1] - a[1]).slice(0, 6);

  // 教科別
  const bySubject = {};
  h.forEach((x) => {
    bySubject[x.subject] ||= { n: 0, sum: 0 };
    bySubject[x.subject].n += 1;
    bySubject[x.subject].sum += x.percent || 0;
  });

  // 苦手パターン
  const byPattern = {};
  h.forEach((x) => {
    byPattern[x.patternId] ||= { n: 0, sum: 0, name: x.patternId };
    byPattern[x.patternId].n += 1;
    byPattern[x.patternId].sum += x.percent || 0;
  });
  const weak = Object.entries(byPattern)
    .map(([k, v]) => ({ id: k, ...v, avg: Math.round(v.sum / v.n) }))
    .filter((x) => x.avg < 70)
    .sort((a, b) => a.avg - b.avg)
    .slice(0, 5);

  el.innerHTML = `
    <h1 class="serif" style="font-size:1.65rem;margin:0 0 6px">航海日誌</h1>
    <p style="color:var(--ink-2);font-size:.88rem">到達度は「答えの正確さ」だけでなく「根拠説明の評価」を含みます。</p>

    <div class="grid grid-4" style="margin:20px 0">
      <div class="stat-tile"><div class="k">ATTEMPTS</div><div class="v">${total}<small> 回</small></div></div>
      <div class="stat-tile"><div class="k">AVERAGE</div><div class="v">${avg}<small> %</small></div></div>
      <div class="stat-tile"><div class="k">FULL MARKS</div><div class="v">${perfect}<small> 回</small></div></div>
      <div class="stat-tile"><div class="k">NEEDS REVIEW</div><div class="v">${needReview}<small> 回</small></div></div>
    </div>

    <div class="grid grid-2">
      <section class="card">
        <div class="card-title"><h3>直近10回の推移</h3><span class="eyebrow">PROGRESS</span></div>
        <div class="spark" style="height:76px">
          ${last10.map((x) => `<span style="height:${Math.max(4, x.percent || 0)}%" title="${esc(x.questionId)} ${x.percent}%"></span>`).join('')}
        </div>
        <div style="display:flex;justify-content:space-between;font-size:.68rem;color:var(--ink-3);margin-top:6px">
          <span>古い</span><span>新しい</span>
        </div>
      </section>

      <section class="card">
        <div class="card-title"><h3>誤答の傾向</h3><span class="eyebrow">DIAGNOSIS</span></div>
        ${errRows.length ? errRows.map(([k, v]) => `
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
            <span style="font-size:.78rem;min-width:130px">${esc(ERROR_LABEL[k] || k)}</span>
            <div class="bar" style="flex:1"><span style="width:${Math.round((v / total) * 100)}%"></span></div>
            <span class="mono" style="font-size:.66rem;color:var(--ink-3)">${v}</span>
          </div>`).join('') : '<div class="empty" style="padding:20px">誤答の分類データはまだありません。</div>'}
      </section>
    </div>

    ${weak.length ? `
    <section class="card" style="margin-top:16px">
      <div class="card-title"><h3>重点復習が必要なパターン</h3><span class="eyebrow">WEAK SPOTS</span></div>
      ${weak.map((w) => `
        <div class="pattern-row">
          <div class="pattern-main">
            <div class="pattern-name">${esc(w.id)}</div>
            <div class="pattern-desc">${w.n} 回 · 平均 ${w.avg}%</div>
          </div>
          <button class="btn btn-sm" data-goto="#/practice?pattern=${encodeURIComponent(w.id)}">復習する</button>
        </div>`).join('')}
    </section>` : ''}

    <div class="rule-fancy"><span class="mono">LOGBOOK</span></div>

    <section class="card" style="padding:10px 18px">
      ${h.slice(0, 60).map((x) => {
        const v = VERDICT[x.verdict] || VERDICT.partial;
        return `
        <div class="hist-row">
          <div class="hist-score chip ${v.cls}" style="border:0">${x.score}/${x.maxScore}</div>
          <div>
            <div><b>${esc(x.questionId)}</b> <span style="color:var(--ink-3)">${esc(x.course || '')} / ${esc(x.unit || '')}</span></div>
            <div class="hist-meta">${esc(x.patternId)} · ${esc(x.difficulty || '')} · ${esc(x.examType || '')} · ${fmtDate(x.createdAt)}${x.gradedBy === 'rubric+ai' ? ' · AI添削' : ''}</div>
          </div>
          <button class="btn btn-sm" data-goto="#/practice/${encodeURIComponent(x.questionId)}">もう一度</button>
        </div>`;
      }).join('')}
    </section>

    <div style="margin-top:18px;display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn btn-sm" id="export-hist">履歴をJSONで書き出す</button>
      <button class="btn btn-sm" id="clear-hist">履歴を消去</button>
    </div>
  `;

  wireGoto(el);
  $('#export-hist', el).addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(S.history, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `chishin-history-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  });
  $('#clear-hist', el).addEventListener('click', () => {
    if (!confirm('学習履歴をすべて削除します。よろしいですか？（この操作は取り消せません）')) return;
    S.history = [];
    saveHistory();
    toast('履歴を削除しました');
    route();
  });
}

// ------------------------------------------------------------------ COVERAGE
function viewCoverage(el) {
  setCrumbs(['整備状況']);
  const sum = S.coverage.summary;
  const rows = S.coverage.rows;
  const pct = sum.targetQuestions ? ((sum.registeredQuestions / sum.targetQuestions) * 100).toFixed(1) : '0.0';

  const subjectStats = Object.entries(sum.bySubject).map(([name, v]) => `
    <div class="stat-tile">
      <div class="k">${esc(name)}</div>
      <div class="v">${v.registered}<small> / ${v.target} 問</small></div>
      <div class="bar" style="margin-top:8px"><span style="width:${v.target ? Math.min(100, (v.registered / v.target) * 100) : 0}%"></span></div>
      <div style="font-size:.68rem;color:var(--ink-3);margin-top:6px">${v.patterns} パターン · 検証済 ${v.verified}</div>
    </div>`).join('');

  el.innerHTML = `
    <h1 class="serif" style="font-size:1.65rem;margin:0 0 6px">整備状況（カバレッジ）</h1>
    <p style="color:var(--ink-2);font-size:.88rem;max-width:820px">
      単元・問題パターンの<b>定義</b>と、実際に登録された<b>問題数</b>は別の状態として管理しています。
      未登録・未検証の範囲はここで常に可視化されます。
    </p>

    <div class="grid grid-4" style="margin:20px 0">
      <div class="stat-tile"><div class="k">PATTERNS</div><div class="v">${sum.patterns}</div></div>
      <div class="stat-tile"><div class="k">TARGET</div><div class="v">${sum.targetQuestions.toLocaleString()}<small> 問</small></div></div>
      <div class="stat-tile"><div class="k">REGISTERED</div><div class="v">${sum.registeredQuestions}<small> 問</small></div></div>
      <div class="stat-tile"><div class="k">COVERAGE</div><div class="v">${pct}<small> %</small></div></div>
    </div>

    <div class="notice notice-info" style="margin-bottom:18px">
      <span class="ico">i</span>
      <div>
        現在 <b>${sum.registeredQuestions}</b> 問を登録（うち内容確認済み <b>${sum.verifiedQuestions}</b> 問）。
        目標 ${sum.targetQuestions.toLocaleString()} 問に対して <b>${pct}%</b>。
        パターン単位では ${sum.patternsWithAnyQuestion} / ${sum.patterns} に1問以上、${sum.completePatterns} パターンが目標数に到達しています。
        問題数を満たすための数値差し替えは行っていません。
      </div>
    </div>

    <div class="grid grid-4" style="margin-bottom:20px">${subjectStats}</div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px;align-items:center">
      <select id="cov-filter" style="max-width:180px">
        <option value="">すべての教科</option>
        ${S.curriculum.subjects.map((s) => `<option value="${SUBJECT_KEY[s.name]}">${esc(s.name)}</option>`).join('')}
      </select>
      <select id="cov-status" style="max-width:200px">
        <option value="">すべての状態</option>
        <option value="unregistered">未登録のみ</option>
        <option value="in_progress">登録途中</option>
        <option value="complete">目標到達</option>
      </select>
      <span class="chip" id="cov-count"></span>
    </div>

    <section class="card" style="padding:0;overflow:hidden">
      <div style="max-height:620px;overflow:auto">
        <table class="coverage-table">
          <thead><tr>
            <th>教科 / 科目</th><th>単元</th><th>問題パターン</th>
            <th class="num">登録</th><th class="num">目標</th><th class="num">検証済</th><th>状態</th>
          </tr></thead>
          <tbody id="cov-body"></tbody>
        </table>
      </div>
    </section>

    <div style="margin-top:18px;display:flex;gap:10px;flex-wrap:wrap">
      <button class="btn btn-sm btn-primary" id="export-report">整備レポートを書き出す</button>
      <button class="btn btn-sm" data-goto="#/curriculum">体系を見る</button>
    </div>
  `;

  const draw = () => {
    const f = $('#cov-filter', el).value;
    const st = $('#cov-status', el).value;
    let list = rows.filter((r) => (!f || r.subjectId === f) && (!st || r.status === st));
    $('#cov-count', el).textContent = `${list.length} パターン`;
    $('#cov-body', el).innerHTML = list.map((r) => {
      const chipCls = r.status === 'complete' ? 'chip-ok' : r.status === 'in_progress' ? 'chip-sea' : 'chip-warn';
      const label = r.status === 'complete' ? '目標到達' : r.status === 'in_progress' ? '登録途中' : '未登録';
      return `<tr>
        <td><span style="font-size:.7rem;color:var(--ink-3)">${esc(r.subjectName)}</span><br>${esc(r.courseName)}</td>
        <td style="font-size:.76rem">${esc(r.unitName)}</td>
        <td><div style="font-size:.8rem">${esc(r.patternName)}</div><div class="pat">${esc(r.patternId)}</div></td>
        <td class="num">${r.registered}</td>
        <td class="num">${r.target}</td>
        <td class="num">${r.verified}</td>
        <td><span class="chip ${chipCls}" style="font-size:.64rem">${label}</span></td>
      </tr>`;
    }).join('');
  };
  $('#cov-filter', el).addEventListener('change', draw);
  $('#cov-status', el).addEventListener('change', draw);
  draw();
  wireGoto(el);

  $('#export-report', el).addEventListener('click', () => {
    const blob = new Blob([JSON.stringify({ summary: sum, rows }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `chishin-coverage-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  });
}

// ------------------------------------------------------------------ SETTINGS
function viewSettings(el) {
  setCrumbs(['設定']);
  const s = S.settings;

  const seg = (key, options) => `
    <div class="segmented" data-setting="${key}">
      ${options.map((o) => `<button data-val="${esc(o.v)}" class="${s[key] === o.v ? 'on' : ''}">${esc(o.label)}</button>`).join('')}
    </div>`;

  el.innerHTML = `
    <h1 class="serif" style="font-size:1.65rem;margin:0 0 6px">設定</h1>
    <p style="color:var(--ink-2);font-size:.88rem">設定はこの端末に保存され、再訪時も維持されます。</p>

    <div class="grid grid-2" style="margin-top:20px">
      <section class="card">
        <div class="card-title"><h3>解答言語</h3><span class="eyebrow">LANGUAGE</span></div>
        <div class="field">
          <div class="desc">英語学習では、英文そのものと解答・説明の言語を独立して扱います。</div>
          ${seg('answerLanguage', [
            { v: 'ja', label: '日本語で解答' },
            { v: 'en', label: 'English' },
            { v: 'per_question', label: '問題ごとに選ぶ' },
          ])}
        </div>

        <div class="card-title" style="margin-top:26px"><h3>解答形式</h3><span class="eyebrow">FORMAT</span></div>
        <div class="field">
          <div class="desc">問題が対応している形式を優先します。auto は問題データの形式に従います。</div>
          ${seg('answerFormat', [
            { v: 'auto', label: '自動（問題に従う）' },
            { v: '選択式', label: '選択式' },
            { v: '記述式', label: '記述式' },
            { v: '証明・論証式', label: '証明・論証' },
            { v: '根拠付き記述式', label: '根拠付き記述' },
          ])}
        </div>
      </section>

      <section class="card">
        <div class="card-title"><h3>思考説明の詳細度</h3><span class="eyebrow">DEPTH</span></div>
        <div class="field">
          <div class="desc">デフォルトは「根拠・判断理由まで詳しく記述」です。</div>
          ${seg('detailLevel', [
            { v: 'brief', label: '簡潔' },
            { v: 'detail', label: '詳細' },
            { v: 'grounds', label: '根拠・判断理由まで' },
            { v: 'alternatives', label: '別解・反例まで' },
          ])}
        </div>

        <div class="card-title" style="margin-top:26px"><h3>学習モード</h3><span class="eyebrow">MODE</span></div>
        <div class="field">
          ${seg('learningMode', [
            { v: 'normal', label: '通常演習' },
            { v: 'hint', label: 'ヒントあり' },
            { v: 'explain', label: '解答後に詳解' },
            { v: 'review', label: '苦手パターン復習' },
            { v: 'timed', label: '時間制限（10分）' },
          ])}
          <div class="desc" style="margin-top:8px">時間制限モードでは、制限時間まで解説を伏せて本番形式で解きます。</div>
        </div>

        <div class="field">
          <label>融合問題の関連単元の表示</label>
          <div class="desc">本番形式の演習では、解答後に表示する設定が有効です。</div>
          ${seg('showReferencedUnits', [
            { v: 'after', label: '解答後に表示' },
            { v: 'before', label: '最初から表示' },
          ])}
        </div>
      </section>
    </div>

    <section class="card" style="margin-top:18px">
      <div class="card-title"><h3>AI（Gemini）設定</h3><span class="eyebrow">AI</span></div>
      <p style="font-size:.84rem;color:var(--ink-2);max-width:720px">
        AI添削・段階ヒント・類題生成に Gemini API を使用します。
        キーは<b>このブラウザにのみ</b>保存され、リクエスト時に API へ転送されます。サーバー側には保存しません。
        使い終わったら下の「キーを削除」で即座に破棄できます。
      </p>
      <div class="field" style="margin-top:14px">
        <label>Gemini API キー</label>
        <div class="desc">キー未設定でも、ルーブリック採点・解説表示・履歴はすべて動作します。</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <input type="text" id="gemini-key" placeholder="AIza... または サーバーで設定済み" value="${esc(S.geminiKey)}" style="flex:1;min-width:240px;font-family:var(--font-mono);font-size:.78rem" />
          <button class="btn btn-sm btn-primary" id="save-key">保存</button>
          <button class="btn btn-sm" id="del-key">キーを削除</button>
        </div>
        <div style="font-size:.72rem;color:var(--ink-3);margin-top:6px" id="key-state"></div>
      </div>
      <div class="notice notice-warn">
        <span class="ico">!</span>
        <div>キーを共有端末に残さないでください。履歴とキーは「履歴を消去」「キーを削除」で個別に消せます。</div>
      </div>
    </section>

    <section class="card" style="margin-top:18px">
      <div class="card-title"><h3>データ管理</h3><span class="eyebrow">DATA</span></div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="btn btn-sm" id="export-all">設定・履歴を書き出す</button>
        <button class="btn btn-sm" id="reset-settings">設定を初期値に戻す</button>
      </div>
      <p style="font-size:.74rem;color:var(--ink-3);margin-top:10px;margin-bottom:0">
        保存先: このブラウザの localStorage（キー: chishin.*）。サーバーには個人データを保存していません。
      </p>
    </section>
  `;

  $$('[data-setting]', el).forEach((group) => {
    $$('button', group).forEach((b) => b.addEventListener('click', () => {
      const key = group.dataset.setting;
      S.settings[key] = b.dataset.val;
      saveSettings();
      $$('button', group).forEach((x) => x.classList.toggle('on', x === b));
      toast('設定を保存しました');
      if (key === 'learningMode' || key === 'detailLevel') {
        // 進行中のセッションに即時反映
        if (S.current) { S.current.remaining = key === 'learningMode' && b.dataset.val === 'timed' ? 600 : undefined; }
      }
    }));
  });

  const ks = $('#key-state', el);
  const updKeyState = () => {
    ks.innerHTML = S.geminiKey
      ? '<span class="chip chip-ok">ブラウザキー設定済み</span> この端末にのみ保存されています。'
      : '<span class="chip">未設定</span> サーバー側のキーが設定されていればそれを使用します。';
  };
  updKeyState();

  $('#save-key', el).addEventListener('click', () => {
    const v = $('#gemini-key', el).value.trim();
    S.geminiKey = v;
    if (v) localStorage.setItem(LS.gemini, v); else localStorage.removeItem(LS.gemini);
    updKeyState();
    checkAi();
    toast(v ? 'キーを保存しました（この端末のみ）' : 'キーを削除しました');
  });
  $('#del-key', el).addEventListener('click', () => {
    S.geminiKey = '';
    localStorage.removeItem(LS.gemini);
    $('#gemini-key', el).value = '';
    updKeyState();
    checkAi();
    toast('キーを削除しました');
  });
  $('#export-all', el).addEventListener('click', () => {
    const blob = new Blob([JSON.stringify({ settings: S.settings, history: S.history }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `chishin-data-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  });
  $('#reset-settings', el).addEventListener('click', () => {
    S.settings = { ...DEFAULT_SETTINGS };
    saveSettings();
    toast('設定を初期値に戻しました');
    route();
  });
}

// ------------------------------------------------------------------ ABOUT
function viewAbout(el) {
  setCrumbs(['使い方と設計']);
  el.innerHTML = `
    <h1 class="serif" style="font-size:1.65rem;margin:0 0 6px">使い方と設計</h1>
    <p style="color:var(--ink-2);font-size:.88rem;max-width:780px">
      このサイトは「正解を当てる」ためではなく、「なぜその答えになるのか」を自分の言葉で再現できるようにするために設計されています。
    </p>

    <div class="grid grid-2" style="margin-top:20px">
      <section class="card">
        <div class="card-title"><h3>解き方（3ステップ）</h3><span class="eyebrow">HOW TO</span></div>
        <ol style="font-size:.86rem;line-height:2;padding-left:20px;color:var(--ink-2)">
          <li><b>単元を選ぶ</b>　「全単元の体系」から単元を開き、問題パターンを確認します。</li>
          <li><b>結論と根拠を書く</b>　解答欄に結論、思考欄に条件・根拠・方針・検証を書きます。空欄でも採点できますが、書くほど評価が上がります。</li>
          <li><b>添削を読む</b>　評価項目ごとの得点、不足している根拠、誤答の分類、詳細解説、類題が表示されます。</li>
        </ol>
      </section>

      <section class="card">
        <div class="card-title"><h3>採点の考え方</h3><span class="eyebrow">GRADING</span></div>
        <ul style="font-size:.84rem;line-height:1.95;padding-left:18px;color:var(--ink-2)">
          <li>文字列の完全一致では判定しません。</li>
          <li>正解でも根拠が誤っていれば満点にしません。</li>
          <li>計算ミスでも方針・途中式が正しければ部分点を与えます。</li>
          <li>数学的・文法的・論理的に正しい別解は認めます。</li>
          <li>判定に確信が持てない場合は「要確認」として断定しません。</li>
        </ul>
      </section>
    </div>

    <section class="card" style="margin-top:18px">
      <div class="card-title"><h3>教材の階層と品質管理</h3><span class="eyebrow">STRUCTURE</span></div>
      <p style="font-size:.84rem;color:var(--ink-2)">
        教科 → 科目 → 大分野 → 単元 → 小単元 → 学習内容 → 問題パターン → 難易度別演習 → 解答・解説 → 復習 の順で整理しています。
        各単元には学習目標・前提知識・重要語句・考え方・他単元との関連を持たせ、各パターンには目標問題数（原則30問）を設定しています。
      </p>
      <div class="grid grid-3" style="margin-top:14px">
        <div class="feedback-block"><h5>難易度</h5><div style="font-size:.78rem;line-height:1.9">基礎 5 / 応用 10 / 発展 10 / 複合・最難関 5</div></div>
        <div class="feedback-block"><h5>出題形式</h5><div style="font-size:.78rem;line-height:1.9">定期考査型・共通テスト型・国公立二次型・私立大型・横断型</div></div>
        <div class="feedback-block"><h5>検証状況</h5><div style="font-size:.78rem;line-height:1.9">内容確認済み / 自動検証済み / 見本（未検証） / AI生成・未検証 を区別</div></div>
      </div>
      <div class="notice notice-warn" style="margin-top:16px">
        <span class="ico">!</span>
        <div>
          問題パターンの<b>定義</b>が全教科分そろっていても、<b>全パターン30問</b>が揃ったわけではありません。
          <a href="#/coverage">整備状況</a>で、登録済み・未登録・未検証を常に区別して表示します。
          未登録のパターンはAI生成で下書きを作れますが、生成物は「未検証」として扱われます。
        </div>
      </div>
    </section>

    <section class="card" style="margin-top:18px">
      <div class="card-title"><h3>ショートカット</h3><span class="eyebrow">KEYS</span></div>
      <table class="rubric-table">
        <tbody>
          <tr><td style="width:150px"><kbd>Ctrl</kbd> + <kbd>Enter</kbd></td><td>解答を提出</td></tr>
          <tr><td><kbd>H</kbd></td><td>ヒントを1段開く</td></tr>
          <tr><td><kbd>Ctrl</kbd> + <kbd>P</kbd></td><td>印刷 / PDF 保存</td></tr>
        </tbody>
      </table>
    </section>
  `;
  wireGoto(el);
}

// ------------------------------------------------------------------ boot hook
window.addEventListener('DOMContentLoaded', boot);

document.addEventListener('keydown', (e) => {
  if (S.route !== 'practice' || !S.current) return;
  const tag = (e.target.tagName || '').toLowerCase();
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
    e.preventDefault();
    submitAnswer(false);
  } else if (e.key.toLowerCase() === 'h' && tag !== 'textarea' && tag !== 'input') {
    e.preventDefault();
    showHint();
  }
});
